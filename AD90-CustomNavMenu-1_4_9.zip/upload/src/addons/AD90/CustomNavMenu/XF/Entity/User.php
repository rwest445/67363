<?php
namespace AD90\CustomNavMenu\XF\Entity;

class User extends XFCP_User
{
    protected function _postDelete()
    {
        parent::_postDelete();
        if ($this->app()->db()->getSchemaManager()->tableExists('xf_custom_nav_user_item')) { $this->db()->delete('xf_custom_nav_user_item', 'user_id = ?', $this->user_id); }
        if ($this->app()->db()->getSchemaManager()->tableExists('xf_custom_nav_user_preference')) { $this->db()->delete('xf_custom_nav_user_preference', 'user_id = ?', $this->user_id); }
    }
}
