<?php
namespace AD90\CustomNavMenu\XF\Entity;

class Permission extends XFCP_Permission
{
    protected function _postDelete()
    {
        parent::_postDelete();
        if ($this->permission_group_id === 'ad90Nav' && preg_match('/^item[0-9]+$/D', $this->permission_id))
        {
            // Also covers translations and a stale cached MasterTitle relation.
            foreach ($this->finder('XF:Phrase')->where('title', $this->getPhraseName())->fetch() as $phrase)
            {
                $phrase->delete();
            }
        }
    }

    public function getTitle()
    {
        if ($this->permission_group_id === 'ad90Nav' && preg_match('/^item([0-9]+)$/D', $this->permission_id, $match))
        {
            $item = $this->em()->find('AD90\CustomNavMenu:MenuItem', (int)$match[1]);
            if ($item) { return \XF::phrase('ad90_nav_permission_name', ['title'=>$item->getPermissionTitle()]); }
        }
        return parent::getTitle();
    }
}
