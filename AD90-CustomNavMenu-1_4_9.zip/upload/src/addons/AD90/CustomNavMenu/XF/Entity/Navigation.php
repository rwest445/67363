<?php
namespace AD90\CustomNavMenu\XF\Entity;

class Navigation extends XFCP_Navigation
{
    protected function _postSave()
    {
        parent::_postSave();
        if ($this->isUpdate() && $this->isChanged('navigation_id'))
        {
            $old = $this->getExistingValue('navigation_id');
            $this->db()->update('xf_ad90_nav_item', ['native_id'=>$this->navigation_id], 'native_id = ?', $old);
            $this->db()->update('xf_ad90_nav_item', ['parent_key'=>$this->navigation_id], 'parent_key = ?', $old);
        }
        $this->app()->registry()->delete('ad90NavItems');
    }

    protected function _postDelete()
    {
        parent::_postDelete();
        foreach ($this->finder('AD90\CustomNavMenu:MenuItem')->where('native_id', $this->navigation_id)->fetch() as $item)
        { $item->delete(); }
        $this->app()->registry()->delete('ad90NavItems');
    }
}
