<?php
namespace AD90\CustomNavMenu\Service;

class UserPanel
{
    public static function templatePreRender(\XF\Template\Templater $templater, &$type, &$template, array &$params)
    {
        if (!\XF::options()->ad90NavEnabled) { return; }
        $user = \XF::visitor();
        $params['ad90Languages'] = array_filter(\XF::app()->container('language.cache'), function ($language) use ($user) {
            return ($user->is_admin || $language['user_selectable']) && (int)$language['language_id'] !== (int)\XF::language()->getId();
        });
        if (!$user->user_id) { return; }
        $params['ad90AccountTiles'] = \XF::app()->repository('AD90\CustomNavMenu:AccountTile')->getVisibleTiles($user);
        $options = \XF::options();
        $providers = [\AD90\CustomNavMenu\StatsProvider\Core::class];
        // XF class extensions can add visitor statistic providers.
        $panel = \XF::app()->service('AD90\CustomNavMenu:Panel');
        static $statsByUser = [];
        if (!isset($statsByUser[$user->user_id])) { $statsByUser[$user->user_id] = $panel->collect($user, $providers); }
        $params['ad90Stats'] = $statsByUser[$user->user_id];
        $params['ad90Vip'] = false;
        foreach (preg_split('/\s*,\s*/', $options->ad90NavVipGroups, -1, PREG_SPLIT_NO_EMPTY) as $id)
        { if ((int)$id && $user->isMemberOf((int)$id)) { $params['ad90Vip'] = true; break; } }
        $group = \XF::em()->find('XF:UserGroup', $user->display_style_group_id ?: $user->user_group_id);
        $params['ad90GroupTitle'] = $group ? $group->title : '';
    }
}
