/**
 * AD90 Breadcrumb.
 *
 * XF.Element handler (data-xf-init="ad90-breadcrumb") mounted on the
 * <ul class="p-breadcrumbs"> container.
 *
 * Why not the stock helpers:
 *  - XF.Menu opens its menu on click only (XF.MenuClick), while here the crumb itself must
 *    stay a plain link and the dropdown must open on hover. That behaviour cannot be
 *    expressed with XF.Menu, so the open/close state is managed locally.
 *  - XF.HScroller adds its own scroll arrows and expects a .hScroller-scroll child; the
 *    breadcrumb row needs plain horizontal overflow with a thin drag handle instead.
 *
 * Everything else follows the framework: the element lifecycle (init/destroy) makes the
 * handler survive AJAX re-activation, XF.on/XF.off are used with the .ad90bc namespace so
 * destroy() can drop global listeners, and no jQuery is used.
 */
!function (window, document, _undefined)
{
	"use strict";

	XF.Ad90Breadcrumb = XF.Element.newHandler({
		options: {
			openDelay: 180,   // hover-in delay
			switchDelay: 120, // delay when switching between two open menus
			closeDelay: 250,  // grace period before closing
			mobileMax: 560    // breakpoint for the horizontal scroller
		},

		menu: null,
		activeWrap: null,
		openTimer: null,
		closeTimer: null,
		canHover: false,

		scroller: null,
		thumb: null,
		thumbTimer: null,
		drag: null,
		mq: null,

		init: function ()
		{
			this.bc = this.target;

			// Devices without hover (touch) must not open the dropdown on tap: the crumb is a
			// link, so a tap has to follow it. They get the horizontal scroller instead.
			this.canHover = !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches);

			if (this.canHover)
			{
				var wraps = this.bc.querySelectorAll('.ad90bc-crumb-wrap');
				for (var i = 0; i < wraps.length; i++)
				{
					var own = wraps[i].querySelector('.ad90bc-menu');
					if (!own)
					{
						continue;
					}

					wraps[i].__ad90Menu = own;

					XF.on(own, 'mouseenter', this.cancelClose.bind(this));
					XF.on(own, 'mouseleave', this.scheduleClose.bind(this));
				}

				XF.on(this.bc, 'mouseover', this.onCrumbOver.bind(this));
				XF.on(this.bc, 'mouseout', this.onCrumbOut.bind(this));
			}

			// Global dismissal handlers. init() runs once per container, and the namespaced
			// handlers are removed in destroy(), so they never pile up.
			this.closeHandler = this.closeNow.bind(this);
			XF.on(document, 'click.ad90bc', this.onDocumentClick.bind(this));
			XF.on(document, 'keydown.ad90bc', this.onKeyDown.bind(this));
			XF.on(window, 'scroll.ad90bc', this.closeHandler, { capture: true });
			XF.on(window, 'resize.ad90bc', this.closeHandler);

			this.initScroller();
		},

		/**
		 * Releases global listeners and restores the breadcrumb container to its original DOM
		 * position (the mobile scroller wraps it).
		 */
		destroy: function ()
		{
			this.closeNow();

			XF.off(document, 'click.ad90bc');
			XF.off(document, 'keydown.ad90bc');
			XF.off(window, 'scroll.ad90bc', this.closeHandler, { capture: true });
			XF.off(window, 'resize.ad90bc');

			if (this.resizeObserver)
			{
				this.resizeObserver.disconnect();
				this.resizeObserver = null;
			}

			if (this.mq)
			{
				if (this.mq.removeEventListener)
				{
					this.mq.removeEventListener('change', this.applyMedia);
				}
				else if (this.mq.removeListener)
				{
					this.mq.removeListener(this.applyMedia);
				}
			}

			this.unwrapScroller();
		},

		// ---------- dropdown menu ----------

		place: function (wrap)
		{
			var m = wrap.__ad90Menu;
			if (!m)
			{
				return;
			}

			this.closeNow();

			this.menu = m;
			this.activeWrap = wrap;

			var r = wrap.getBoundingClientRect();
			var width = m.offsetWidth;
			var left = Math.max(8, Math.min(r.left, window.innerWidth - width - 8));
			m.style.left = left + 'px';
			m.style.top = r.bottom + 'px';

			m.getBoundingClientRect(); // apply the start state before the animation
			m.classList.add('is-active');
			m.setAttribute('aria-hidden', 'false');

			var crumb = wrap.querySelector('.ad90bc-crumb');
			if (crumb)
			{
				crumb.setAttribute('aria-expanded', 'true');
			}
		},

		open: function (wrap)
		{
			clearTimeout(this.openTimer);

			if (this.activeWrap === wrap)
			{
				this.cancelClose();
				return;
			}

			if (this.activeWrap)
			{
				// fade the previous one out in place, then open the new one
				this.closeNow();
				this.openTimer = setTimeout(this.place.bind(this, wrap), this.options.switchDelay);
				return;
			}

			this.place(wrap);
		},

		closeNow: function ()
		{
			clearTimeout(this.openTimer);
			this.cancelClose();

			if (!this.menu)
			{
				return;
			}

			this.menu.classList.remove('is-active');
			this.menu.setAttribute('aria-hidden', 'true');

			if (this.activeWrap)
			{
				var crumb = this.activeWrap.querySelector('.ad90bc-crumb');
				if (crumb)
				{
					crumb.setAttribute('aria-expanded', 'false');
				}
			}

			this.menu = null;
			this.activeWrap = null;
		},

		scheduleClose: function ()
		{
			clearTimeout(this.closeTimer);
			this.closeTimer = setTimeout(this.closeNow.bind(this), this.options.closeDelay);
		},

		cancelClose: function ()
		{
			clearTimeout(this.closeTimer);
		},

		onCrumbOver: function (e)
		{
			var wrap = e.target.closest ? e.target.closest('.ad90bc-crumb-wrap') : null;
			if (!wrap || !wrap.__ad90Menu)
			{
				return;
			}

			this.cancelClose();

			if (wrap === this.activeWrap)
			{
				clearTimeout(this.openTimer);
				return;
			}

			if (this.activeWrap)
			{
				this.closeNow();
			}

			clearTimeout(this.openTimer);
			this.openTimer = setTimeout(this.open.bind(this, wrap), this.options.openDelay);
		},

		onCrumbOut: function (e)
		{
			var wrap = e.target.closest ? e.target.closest('.ad90bc-crumb-wrap') : null;
			if (!wrap)
			{
				return;
			}
			if (e.relatedTarget && wrap.contains(e.relatedTarget))
			{
				return;
			}

			clearTimeout(this.openTimer);
			this.scheduleClose();
		},

		onDocumentClick: function (e)
		{
			if (!this.activeWrap)
			{
				return;
			}
			if (this.activeWrap.contains(e.target) || (this.menu && this.menu.contains(e.target)))
			{
				return;
			}

			this.closeNow();
		},

		onKeyDown: function (e)
		{
			if (e.key === 'Escape')
			{
				this.closeNow();
			}
		},

		// ---------- mobile horizontal scroller ----------

		initScroller: function ()
		{
			this.mq = window.matchMedia ? window.matchMedia('(max-width: ' + this.options.mobileMax + 'px)') : null;
			if (!this.mq)
			{
				return;
			}

			this.applyMedia = this.applyMedia.bind(this);
			this.updateThumb = this.updateThumb.bind(this);

			this.applyMedia();

			if (this.mq.addEventListener)
			{
				this.mq.addEventListener('change', this.applyMedia);
			}
			else if (this.mq.addListener)
			{
				this.mq.addListener(this.applyMedia);
			}

			XF.on(window, 'resize.ad90bc-thumb', this.updateThumb);
			XF.on(window, 'load.ad90bc-thumb', this.updateThumb);

			if (document.fonts && document.fonts.ready)
			{
				document.fonts.ready.then(this.updateThumb);
			}
			if (window.ResizeObserver)
			{
				try
				{
					this.resizeObserver = new ResizeObserver(this.updateThumb);
					this.resizeObserver.observe(this.bc);
				}
				catch (e) {}
			}
		},

		applyMedia: function ()
		{
			if (this.mq.matches)
			{
				this.wrapScroller();
			}
			else
			{
				this.unwrapScroller();
			}
		},

		thumbMetrics: function ()
		{
			var sw = this.bc.scrollWidth;
			var cw = this.bc.clientWidth;
			var wd = Math.max(32, cw * cw / sw);
			return { w: wd, track: cw - wd, max: sw - cw };
		},

		updateThumb: function ()
		{
			if (!this.thumb)
			{
				return;
			}

			var m = this.thumbMetrics();
			if (m.max <= 1)
			{
				this.thumb.style.display = 'none';
				return;
			}

			this.thumb.style.display = 'block';
			this.thumb.style.width = m.w + 'px';
			this.thumb.style.transform = 'translateX(' + (this.bc.scrollLeft / m.max * m.track) + 'px)';
		},

		onScroll: function ()
		{
			this.updateThumb();
			if (!this.thumb)
			{
				return;
			}

			this.thumb.classList.add('is-scrolling');
			clearTimeout(this.thumbTimer);
			this.thumbTimer = setTimeout(function ()
			{
				if (this.thumb)
				{
					this.thumb.classList.remove('is-scrolling');
				}
			}.bind(this), 700);
		},

		endDrag: function ()
		{
			this.drag = null;
			if (this.thumb)
			{
				this.thumb.classList.remove('is-drag');
			}
		},

		wrapScroller: function ()
		{
			if (this.scroller || !this.bc.parentNode)
			{
				return;
			}

			this.scroller = document.createElement('div');
			this.scroller.className = 'ad90bc-scroller';
			this.bc.parentNode.insertBefore(this.scroller, this.bc);
			this.scroller.appendChild(this.bc);

			this.thumb = document.createElement('div');
			this.thumb.className = 'ad90bc-thumb';
			this.thumb.setAttribute('aria-hidden', 'true');
			this.scroller.appendChild(this.thumb);

			XF.on(this.thumb, 'pointerdown', function (e)
			{
				e.preventDefault();
				this.drag = { x: e.clientX, left: this.bc.scrollLeft };
				this.thumb.classList.add('is-drag');
				try { this.thumb.setPointerCapture(e.pointerId); } catch (err) {}
			}.bind(this));

			XF.on(this.thumb, 'pointermove', function (e)
			{
				if (!this.drag)
				{
					return;
				}
				var m = this.thumbMetrics();
				if (m.track <= 0)
				{
					return;
				}
				this.bc.scrollLeft = this.drag.left + (e.clientX - this.drag.x) * m.max / m.track;
			}.bind(this));

			XF.on(this.thumb, 'pointerup', this.endDrag.bind(this));
			XF.on(this.thumb, 'pointercancel', this.endDrag.bind(this));

			XF.on(this.bc, 'scroll.ad90bc-thumb', this.onScroll.bind(this), { passive: true });
			this.updateThumb();
		},

		unwrapScroller: function ()
		{
			if (!this.scroller)
			{
				return;
			}

			XF.off(this.bc, 'scroll.ad90bc-thumb');

			if (this.scroller.parentNode)
			{
				this.scroller.parentNode.insertBefore(this.bc, this.scroller);
				this.scroller.parentNode.removeChild(this.scroller);
			}

			this.scroller = null;
			this.thumb = null;
		}
	});

	XF.Element.register('ad90-breadcrumb', 'XF.Ad90Breadcrumb');
}(window, document);
