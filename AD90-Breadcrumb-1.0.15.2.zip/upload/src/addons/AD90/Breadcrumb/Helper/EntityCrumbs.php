<?php

namespace AD90\Breadcrumb\Helper;

use AD90\Breadcrumb\Helper\Menu\Registry;
use XF\Entity\User;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\View;
use XF\Pub\App;

/**
 * Entity crumbs: the "way back" crumb that core templates do not always emit.
 *
 * A page of a single entity (a member profile, a resource) should keep a link to that entity
 * when the visitor is on one of its sub-pages, and must not repeat it on the entity's own
 * page. This class only appends the crumb; Listener::removeCurrentPageCrumb() decides whether
 * it survives, so the "current page" rule stays in exactly one place.
 *
 * Every known entity is listed here, so adding another one does not require touching the
 * listener, the template or any controller.
 */
class EntityCrumbs
{
	/**
	 * Appends entity crumbs for the reply, in trail order.
	 *
	 * @param App           $app
	 * @param array         $params
	 * @param AbstractReply $reply
	 */
	public static function extend(App $app, array &$params, AbstractReply $reply)
	{
		if (!$reply instanceof View)
		{
			return;
		}

		$crumbs = isset($params['breadcrumbs']) && is_array($params['breadcrumbs'])
			? $params['breadcrumbs']
			: [];

		$crumbs = self::addCategoryCrumb($app, $crumbs, $reply);
		$crumbs = self::addMemberCrumb($app, $crumbs, $reply);
		$crumbs = self::addResourceCrumb($app, $crumbs, $reply);

		$params['breadcrumbs'] = $crumbs;
	}

	/**
	 * The category crumb itself on a category page (forum and resource category).
	 *
	 * Core templates call getBreadcrumbs(false), which lists the parents only: the category
	 * the visitor is in is left out, so its own sub-categories cannot be reached without going
	 * back. The crumb is added here with its source, so the menu lists the sub-categories of
	 * the current category (the same behaviour as "Forum / Category / Sub-category" trails).
	 *
	 * The crumb is kept on its own page by Listener::removeCurrentPageCrumb(), because a
	 * category crumb always carries a source.
	 *
	 * @param array $crumbs
	 *
	 * @return array
	 */
	protected static function addCategoryCrumb(App $app, array $crumbs, View $reply): array
	{
		$router = $app->router('public');

		$forum = $reply->getParam('forum');
		if ($forum instanceof \XF\Entity\Forum && $forum->Node)
		{
			return self::appendCrumb(
				$crumbs,
				(string) $forum->Node->title,
				$router->buildLink('forums', $forum),
				Registry::SOURCE_NODE,
				(int) $forum->node_id
			);
		}

		$category = $reply->getParam('category');
		if ($category instanceof \XFRM\Entity\Category)
		{
			return self::appendCrumb(
				$crumbs,
				(string) $category->title,
				$router->buildLink('resources/categories', $category),
				Registry::SOURCE_XFRM_CATEGORY,
				(int) $category->resource_category_id
			);
		}

		return $crumbs;
	}

	/**
	 * Username crumb on member profiles.
	 *
	 * member_view does not emit a breadcrumb of its own, so the crumb is added here rather
	 * than by extending the member controller. The user comes from the view reply: the
	 * container params do not carry view params.
	 *
	 * @param array $crumbs
	 *
	 * @return array
	 */
	protected static function addMemberCrumb(App $app, array $crumbs, View $reply): array
	{
		$user = $reply->getParam('user');
		if (!$user instanceof User)
		{
			return $crumbs;
		}

		return self::appendCrumb(
			$crumbs,
			(string) $user->username,
			$app->router('public')->buildLink('members', $user)
		);
	}

	/**
	 * Resource crumb on resource sub-pages (updates, reviews, history, ...).
	 *
	 * XenForo Resource Manager only emits category crumbs there, so the resource itself would
	 * be unreachable from its own sub-pages. On the resource page the crumb links to the
	 * current URL and is dropped by the listener.
	 *
	 * @param array $crumbs
	 *
	 * @return array
	 */
	protected static function addResourceCrumb(App $app, array $crumbs, View $reply): array
	{
		if (!class_exists('XFRM\Entity\ResourceItem'))
		{
			return $crumbs;
		}

		$addOn = $app->addOnManager()->getById('XFRM');
		if (!$addOn || !$addOn->active)
		{
			return $crumbs;
		}

		$resource = $reply->getParam('resource');
		if (!$resource instanceof \XFRM\Entity\ResourceItem)
		{
			return $crumbs;
		}

		return self::appendCrumb(
			$crumbs,
			(string) $resource->title,
			$app->router('public')->buildLink('resources', $resource)
		);
	}

	/**
	 * Appends a crumb unless the trail already contains the same link.
	 *
	 * @param array  $crumbs
	 * @param string $source   Breadcrumb source ("node", "xfrm_category") or '' for no menu.
	 * @param int    $sourceId Entity id of the source.
	 *
	 * @return array
	 */
	protected static function appendCrumb(array $crumbs, string $value, string $href, string $source = '', int $sourceId = 0): array
	{
		foreach ($crumbs AS $crumb)
		{
			if (is_array($crumb) && (string) ($crumb['href'] ?? '') === $href)
			{
				return $crumbs;
			}
		}

		$crumbs[] = [
			'value'     => $value,
			'href'      => $href,
			'node_id'   => 0,
			'source'    => $source,
			'source_id' => $sourceId,
		];

		return $crumbs;
	}
}