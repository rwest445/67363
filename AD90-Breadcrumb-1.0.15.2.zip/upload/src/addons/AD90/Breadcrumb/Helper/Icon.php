<?php

namespace AD90\Breadcrumb\Helper;

use XF\Entity\Node;

/**
 * Icon data for the sub-forum menu.
 *
 * The class returns plain data describing what to draw; the template renders it.
 * [XFA] Nodes Icon Tweak support lives in XfaIcon and is only consulted when the add-on
 * is installed and active, so the core path never touches its columns or methods.
 */
class Icon
{
	/**
	 * Icon description for a node.
	 *
	 * Returned keys:
	 *  - type:  'fa' | 'image' | 'sprite' | 'none'
	 *  - class: Font Awesome class (type = fa)
	 *  - url:   image URL (type = image/sprite)
	 *  - style: inline CSS for the icon element (type = fa/sprite), already validated
	 *
	 * @return array<string, mixed>
	 */
	public static function getIconData(Node $node): array
	{
		if (XfaIcon::isAvailable())
		{
			$icon = XfaIcon::getIconData($node);
			if ($icon)
			{
				return $icon;
			}
		}

		return self::getDefaultIconData($node);
	}

	/**
	 * Stock XenForo icon: forums get their forum type icon, other nested nodes get an empty <i>.
	 *
	 * Mirrors xfa_nit_node_list's fallback branch so the menu looks the same with and without
	 * [XFA] Nodes Icon Tweak.
	 *
	 * @return array<string, mixed>
	 */
	protected static function getDefaultIconData(Node $node): array
	{
		if (!$node->parent_node_id || $node->node_type_id !== 'Forum')
		{
			return ['type' => 'none'];
		}

		$class = 'fa-comments';

		$forum = $node->Data;
		if ($forum && method_exists($forum, 'getTypeHandler'))
		{
			$typeHandler = $forum->getTypeHandler();
			if ($typeHandler)
			{
				$class = $typeHandler->getTypeIconClass() ?: 'fa-comments';
			}
		}

		return [
			'type'  => 'fa',
			'class' => self::sanitizeFaClass($class),
			'style' => '',
		];
	}

	/**
	 * Font Awesome class names are limited to the characters FA actually uses.
	 */
	public static function sanitizeFaClass(string $class): string
	{
		$class = trim($class);

		return preg_match('/^[a-z0-9\- ]{1,100}$/i', $class) ? $class : 'fa-comments';
	}

	/**
	 * CSS color for an inline style attribute, or an empty string when it does not look like a color.
	 */
	public static function sanitizeColor(string $color): string
	{
		$color = trim($color);
		if ($color === '')
		{
			return '';
		}

		$hex = '/^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i';
		$named = '/^[a-z]{3,20}$/i';
		$functional = '/^(?:rgb|rgba|hsl|hsla)\([0-9.,%\s]{1,40}\)$/i';

		return (preg_match($hex, $color) || preg_match($named, $color) || preg_match($functional, $color))
			? $color
			: '';
	}

	/**
	 * URL suitable for a CSS url() token, or an empty string when it does not look like a URL.
	 *
	 * Only http(s), protocol-relative, root-relative and data:image URLs are accepted, and the
	 * value must not contain characters that could break out of the declaration.
	 */
	public static function sanitizeUrl(string $url): string
	{
		$url = trim($url);
		if ($url === '' || preg_match('/[\s\'"()\\\\<>]/', $url))
		{
			return '';
		}

		$allowed = '#^(?:https?://|//|/|data:image/)#i';

		return preg_match($allowed, $url) ? $url : '';
	}
}
