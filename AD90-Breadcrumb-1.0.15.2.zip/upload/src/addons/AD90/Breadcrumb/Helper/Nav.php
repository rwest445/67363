<?php

namespace AD90\Breadcrumb\Helper;

use AD90\Breadcrumb\Helper\Menu\Registry;
use XF\Template\Templater;

/**
 * Template entry point for the breadcrumb dropdown menu.
 *
 * The class returns plain data: the template ad90_bc_crumbs renders the markup, so every
 * value is escaped by the template layer and no HTML is built here.
 *
 * Which data to load is decided by the breadcrumb source, not by parsing a link: the
 * Listener stores "node" or "xfrm_category" plus an id on each crumb, and the registry
 * dispatches to the matching source (see Helper\Menu).
 */
class Nav
{
	/**
	 * Template function ad90_bc_sub_nodes(source, id): sub-items of a breadcrumb.
	 *
	 * An unknown source or a negative id returns an empty list, so the template renders no
	 * menu at all instead of guessing an id of another entity type. Id 0 is valid: it means
	 * the top level of a source (the "Resources" crumb lists the top level categories).
	 *
	 * @return array<int, array{href: string, title: string, icon: array}>
	 */
	public static function fnSubNodes(Templater $templater, &$escape, $source = '', $id = 0): array
	{
		// Structured data, not markup: the template escapes each value itself.
		$escape = false;

		return Registry::getItems((string) $source, (int) $id);
	}
}
