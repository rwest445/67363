<?php

namespace AD90\Breadcrumb\Helper\Menu;

/**
 * A source of sub-items for a breadcrumb.
 *
 * A breadcrumb carries a source id and an entity id (see Listener::normalizeCrumbs()), and
 * the registry asks the matching source for the sub-items. Adding another breadcrumb type
 * (a forum node, a resource category, a future content type) means adding one implementation
 * of this interface and registering it; nothing else in the add-on changes.
 */
interface SourceInterface
{
	/**
	 * Source id stored on the breadcrumb, e.g. "node" or "xfrm_category".
	 */
	public function getId(): string;

	/**
	 * Whether the source can produce items at all (its add-on is installed and active).
	 *
	 * When this returns false the menu is simply not rendered, so the add-on keeps working
	 * on boards where the optional component is missing.
	 */
	public function isAvailable(): bool;

	/**
	 * Sub-items of the given entity, already filtered by the visitor's view permission.
	 *
	 * @param int $id
	 *
	 * @return array<int, array{href: string, title: string, icon: array}>
	 */
	public function getItems(int $id): array;
}
