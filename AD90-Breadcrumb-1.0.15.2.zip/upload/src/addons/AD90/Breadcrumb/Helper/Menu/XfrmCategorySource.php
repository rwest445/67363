<?php

namespace AD90\Breadcrumb\Helper\Menu;

use XFRM\Entity\Category;
use XF\Tree;

/**
 * Resource category source: viewable child categories of a XenForo Resource Manager category.
 *
 * XenForo Resource Manager is optional for this add-on. Everything below is guarded by
 * isAvailable(), so on boards without XFRM the source reports "nothing to show" instead of
 * touching classes that are not installed.
 *
 * Id 0 is the resource manager itself: the "Resources" crumb uses it to list the top level
 * categories. Ids above zero are resource categories.
 *
 * Data comes from XFRM\Repository\Category, which extends XF\Repository\AbstractCategoryTree:
 * getViewableCategories() eager loads the visitor's permission rows and then calls
 * filterViewable() (XF\Entity\AbstractCategoryTree::canView() ->
 * XFRM\Entity\Category::canView() -> hasResourceCategoryPermission('view')), so a category
 * the visitor may not see never reaches the menu. The whole tree is fetched once per request.
 */
class XfrmCategorySource implements SourceInterface
{
	public const ADDON_ID = 'XFRM';

	/** @var bool|null */
	protected static $available;

	/** @var Tree|null */
	protected static $categoryTree;

	public function getId(): string
	{
		return Registry::SOURCE_XFRM_CATEGORY;
	}

	public function isAvailable(): bool
	{
		if (self::$available === null)
		{
			$addOn = \XF::app()->addOnManager()->getById(self::ADDON_ID);

			self::$available = ($addOn !== null && $addOn->active)
				&& class_exists('XFRM\Repository\Category');
		}

		return self::$available;
	}

	/**
	 * @return array<int, array{href: string, title: string, icon: array}>
	 */
	public function getItems(int $id): array
	{
		if ($id < 0 || !$this->isAvailable())
		{
			return [];
		}

		$tree = self::getCategoryTree();
		if (!$tree)
		{
			return [];
		}

		$router = \XF::app()->router('public');

		$output = [];
		foreach ($tree->children($id) AS $childId => $subTree)
		{
			/** @var Category $category */
			$category = $subTree->record;

			$output[$childId] = [
				'href'  => $router->buildLink('resources/categories', $category),
				'title' => $category->title,
				// Resource categories have no [XFA] Nodes Icon Tweak icons; the icon layer is
				// optional, so no icon is drawn for them.
				'icon'  => ['type' => 'none'],
			];
		}

		return $output;
	}

	/**
	 * The viewable category tree shared by all crumbs of the request.
	 */
	protected static function getCategoryTree(): ?Tree
	{
		if (self::$categoryTree === null)
		{
			try
			{
				/** @var \XFRM\Repository\Category $categoryRepo */
				$categoryRepo = \XF::repository('XFRM:Category');
				$categories = $categoryRepo->getViewableCategories();

				self::$categoryTree = $categoryRepo->createCategoryTree($categories);
			}
			catch (\Throwable $e)
			{
				// A half-removed XFRM install must not break the whole page.
				self::$categoryTree = null;
			}
		}

		return self::$categoryTree;
	}
}
