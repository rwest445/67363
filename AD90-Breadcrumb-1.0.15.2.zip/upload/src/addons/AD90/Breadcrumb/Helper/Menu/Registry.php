<?php

namespace AD90\Breadcrumb\Helper\Menu;

/**
 * Breadcrumb source registry.
 *
 * The registry maps the source id stored on a breadcrumb to the object that can list its
 * sub-items. Sources are built lazily and cached for the request, so a page with several
 * breadcrumbs of the same source still loads its data once.
 */
class Registry
{
	public const SOURCE_NODE = 'node';
	public const SOURCE_XFRM_CATEGORY = 'xfrm_category';

	/** @var array<string, SourceInterface|null> */
	protected static $sources = [];

	/** @var array<string, array<int, array>> */
	protected static $cache = [];

	/**
	 * Items for a breadcrumb, or an empty array when the source is unknown or unavailable.
	 *
	 * Id 0 means "the top level of this source": the resource overview crumb uses it to list
	 * the top level resource categories.
	 *
	 * @return array<int, array{href: string, title: string, icon: array}>
	 */
	public static function getItems(string $source, int $id): array
	{
		if ($source === '' || $id < 0)
		{
			return [];
		}

		$cacheKey = $source . ':' . $id;
		if (isset(self::$cache[$cacheKey]))
		{
			return self::$cache[$cacheKey];
		}

		$handler = self::getSource($source);
		$items = $handler && $handler->isAvailable() ? $handler->getItems($id) : [];

		self::$cache[$cacheKey] = $items;

		return $items;
	}

	/**
	 * Whether the source is registered and can produce items at all.
	 */
	public static function isAvailable(string $source): bool
	{
		$handler = self::getSource($source);

		return $handler !== null && $handler->isAvailable();
	}

	/**
	 * The source object for an id, or null when the id is not registered.
	 */
	public static function getSource(string $source): ?SourceInterface
	{
		if (array_key_exists($source, self::$sources))
		{
			return self::$sources[$source];
		}

		$class = self::getSourceClass($source);
		$handler = $class ? new $class() : null;

		self::$sources[$source] = $handler;

		return $handler;
	}

	/**
	 * Known sources. An unknown breadcrumb source deliberately resolves to nothing: the menu
	 * is not rendered and no id from another entity type is substituted.
	 */
	protected static function getSourceClass(string $source): ?string
	{
		switch ($source)
		{
			case self::SOURCE_NODE:
				return NodeSource::class;

			case self::SOURCE_XFRM_CATEGORY:
				return XfrmCategorySource::class;
		}

		return null;
	}
}
