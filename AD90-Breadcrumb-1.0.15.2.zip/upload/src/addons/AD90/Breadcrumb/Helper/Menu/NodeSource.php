<?php

namespace AD90\Breadcrumb\Helper\Menu;

use AD90\Breadcrumb\Helper\Icon;
use XF\Entity\Node;
use XF\Tree;

/**
 * Sub-forum source: visible child nodes of a forum node.
 *
 * NodeRepository::getNodeList() is the same source the forum list uses: it applies
 * display_in_list, loads node type data in bulk and filters by node permissions, so the
 * whole menu costs one query per request.
 */
class NodeSource implements SourceInterface
{
	/** @var Tree|null */
	protected static $nodeTree;

	public function getId(): string
	{
		return Registry::SOURCE_NODE;
	}

	public function isAvailable(): bool
	{
		return true;
	}

	/**
	 * @return array<int, array{href: string, title: string, icon: array}>
	 */
	public function getItems(int $id): array
	{
		if ($id <= 0)
		{
			return [];
		}

		$tree = self::getNodeTree();
		$router = \XF::app()->router('public');

		$output = [];
		foreach ($tree->children($id) AS $childId => $subTree)
		{
			/** @var Node $node */
			$node = $subTree->record;

			$route = $node->getRoute('public');
			if ($route === '')
			{
				continue;
			}

			$output[$childId] = [
				'href'  => $router->buildLink($route, $node),
				'title' => $node->title,
				'icon'  => Icon::getIconData($node),
			];
		}

		return $output;
	}

	/**
	 * The node tree shared by all crumbs of the request.
	 */
	protected static function getNodeTree(): Tree
	{
		if (self::$nodeTree === null)
		{
			/** @var \XF\Repository\NodeRepository $nodeRepo */
			$nodeRepo = \XF::repository('XF:Node');

			self::$nodeTree = $nodeRepo->createNodeTree($nodeRepo->getNodeList());
		}

		return self::$nodeTree;
	}
}
