<?php

namespace AD90\Breadcrumb\Helper;

use XF\Entity\Node;

/**
 * Optional integration with [XFA] Nodes Icon Tweak.
 *
 * This is the only class that knows about the add-on. It is used when the add-on is
 * installed and active and falls back to the stock XenForo icon otherwise — the same
 * approach AD90 CustomThreadView uses for SV MultiPrefix.
 *
 * The add-on stores its settings in the xfa_nit_type / xfa_nit_params columns, so those
 * columns are only read after the add-on has been confirmed active.
 */
class XfaIcon
{
	public const ADDON_ID = 'XFA/NodesIconTweak';

	/** @var bool|null */
	protected static $available;

	/**
	 * Whether [XFA] Nodes Icon Tweak is installed and active.
	 */
	public static function isAvailable(): bool
	{
		if (self::$available === null)
		{
			$addOn = \XF::app()->addOnManager()->getById(self::ADDON_ID);

			self::$available = ($addOn !== null && $addOn->active)
				&& method_exists(Node::class, 'getServerIconUrl');
		}

		return self::$available;
	}

	/**
	 * Icon data configured in [XFA] Nodes Icon Tweak, or null when the node uses stock icons.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function getIconData(Node $node): ?array
	{
		$type = (int) ($node->xfa_nit_type ?? 0);
		if ($type === 0)
		{
			return null;
		}

		$params = $node->xfa_nit_params ?? [];
		if (!is_array($params))
		{
			return null;
		}

		switch ($type)
		{
			case 1:
				return self::fontAwesomeIcon($params);

			case 2:
				return self::serverIcon($node, $params);

			case 3:
				return self::spriteIcon($params);
		}

		// Other types (avatar of the latest poster and newer additions) are not supported
		// by the menu; fall back to the stock icon.
		return null;
	}

	/**
	 * @return array<string, mixed>|null
	 */
	protected static function fontAwesomeIcon(array $params): ?array
	{
		// The first layer is the visible icon; the second one is the "unread" variant.
		$layer = $params['fa_icon1'] ?? [];
		$class = (string) ($layer['layer_down'] ?? '');
		if ($class === '')
		{
			return null;
		}

		$style = '';
		$color = Icon::sanitizeColor((string) ($layer['layer_down_color'] ?? ''));
		if ($color !== '')
		{
			$style .= 'color: ' . $color . ';';
		}

		$size = (int) ($layer['size'] ?? 0);
		if ($size > 0 && $size <= 200)
		{
			$style .= ' font-size: ' . $size . 'px;';
		}

		return [
			'type'  => 'fa',
			'class' => Icon::sanitizeFaClass($class),
			'style' => $style,
		];
	}

	/**
	 * @return array<string, mixed>|null
	 */
	protected static function serverIcon(Node $node, array $params): ?array
	{
		$icon = (string) ($params['srv_icon1']['icon'] ?? '');
		if ($icon === '')
		{
			return null;
		}

		return [
			'type' => 'image',
			'url'  => $node->getServerIconUrl($icon, 'normal', false, true),
		];
	}

	/**
	 * @return array<string, mixed>|null
	 */
	protected static function spriteIcon(array $params): ?array
	{
		$sprite = $params['sprite_icon1'] ?? [];

		$url = Icon::sanitizeUrl((string) ($sprite['icon'] ?? ''));
		if ($url === '')
		{
			return null;
		}

		$size = (int) ($sprite['size'] ?? 32);
		if ($size <= 0 || $size > 2000)
		{
			$size = 32;
		}

		$x = max(0, (int) ($sprite['x'] ?? 0));
		$y = max(0, (int) ($sprite['y'] ?? 0));

		$style = 'background-image: url(' . $url . ');'
			. ' background-position: -' . $x . 'px -' . $y . 'px;'
			. ' background-size: ' . $size . 'px ' . $size . 'px;';

		return [
			'type'  => 'sprite',
			'url'   => $url,
			'style' => $style,
		];
	}
}
