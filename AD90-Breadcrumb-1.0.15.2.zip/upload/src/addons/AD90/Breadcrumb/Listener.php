<?php

namespace AD90\Breadcrumb;

use AD90\Breadcrumb\Helper\Menu\Registry;
use XF\Container;
use XF\Mvc\Renderer\AbstractRenderer;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\View;
use XF\Pub\App;
use XF\Template\Templater;

/**
 * Code event listeners for AD90 Breadcrumb.
 *
 * The add-on does not extend any core class:
 *  - templater_setup registers the single template function used by the crumb macro;
 *  - app_pub_render_page builds the final breadcrumb trail once per request, which is the
 *    last point where the container template params can still be changed.
 *
 * The whole trail (site root, selected navigation entry, page breadcrumbs) is assembled here
 * and handed to the template as a ready list, so the "which crumbs are shown" rules live in
 * one place instead of being split between PHP and template conditions.
 */
class Listener
{
	/**
	 * Registers ad90_bc_sub_nodes(), which returns data (not HTML) for the sub-item menu.
	 */
	public static function templaterSetup(Container $container, Templater &$templater)
	{
		$templater->addFunction('ad90_bc_sub_nodes', [Helper\Nav::class, 'fnSubNodes']);
	}

	/**
	 * Builds the breadcrumb trail right before the page HTML is rendered.
	 *
	 * XF\Pub\App::renderPageHtml() assembles the final param set (page params such as
	 * breadcrumbs, navTree and selectedNavEntry included) and fires this event immediately
	 * before rendering the container template.
	 *
	 * navTree and selectedNavEntry are left untouched — the same params drive the header
	 * navigation menu and its active state.
	 *
	 * @param App              $app
	 * @param array            $params
	 * @param AbstractReply    $reply
	 * @param AbstractRenderer $renderer
	 */
	public static function appPubRenderPage(App $app, array &$params, AbstractReply $reply, AbstractRenderer $renderer)
	{
		// Always defined, so the included template never reads an undefined variable.
		$params['ad90_bc_crumbs'] = [];
		$params['ad90_bc_hidden'] = true;

		$template = self::resolveTemplateName($params, $reply);

		if ($template !== '' && self::isExcluded($template))
		{
			$params['breadcrumbs'] = [];

			return;
		}

		Helper\EntityCrumbs::extend($app, $params, $reply);

		$crumbs = self::normalizeCrumbs($params['breadcrumbs'] ?? []);
		$trail = self::buildTrail($app, $params, $crumbs);
		$trail = self::removeCurrentPageCrumb($app, $trail);

		// A single crumb only links back to where the visitor already is (or to nothing at
		// all), so a trail shorter than two items is not shown anywhere.
		if (count($trail) < 2)
		{
			$params['breadcrumbs'] = [];

			return;
		}

		$params['ad90_bc_crumbs'] = $trail;
		$params['ad90_bc_hidden'] = false;
	}

	/**
	 * The complete trail in display order: site root, selected navigation entry, page crumbs.
	 *
	 * @param array $crumbs Normalized page crumbs.
	 *
	 * @return array
	 */
	protected static function buildTrail(App $app, array $params, array $crumbs): array
	{
		$trail = [];
		$current = self::normalizeUrl($app->request()->getRequestUri());

		$rootBreadcrumb = self::getRootBreadcrumb($params);
		$rootHref = '';
		if ($rootBreadcrumb)
		{
			$rootHref = self::normalizeUrl((string) $rootBreadcrumb['href']);
			if ($rootHref !== $current)
			{
				$trail[] = $rootBreadcrumb;
			}
		}

		// The navigation entry is a section, not an entity page: it stays in the trail even on
		// its own overview page ("Forum / Resources" on the resource overview). It is only
		// skipped when it would repeat the site root.
		$navEntry = self::getNavEntryCrumb($app, $params);
		if ($navEntry && self::normalizeUrl((string) $navEntry['href']) !== $rootHref)
		{
			$trail[] = $navEntry;
		}

		foreach ($crumbs AS $crumb)
		{
			$trail[] = $crumb;
		}

		return $trail;
	}

	/**
	 * The site root crumb ("Forum") from the navigation tree.
	 */
	protected static function getRootBreadcrumb(array $params): ?array
	{
		$navTree = isset($params['navTree']) && is_array($params['navTree']) ? $params['navTree'] : [];
		$key = (string) (\XF::options()->rootBreadcrumb ?? '');

		$entry = $key !== '' ? ($navTree[$key] ?? null) : null;
		if (!is_array($entry) || empty($entry['href']))
		{
			return null;
		}

		return [
			'value'     => (string) ($entry['title'] ?? ''),
			'href'      => (string) $entry['href'],
			'source'    => '',
			'source_id' => 0,
		];
	}

	/**
	 * The selected navigation entry ("Resources" on XFRM pages) as a crumb.
	 *
	 * The resource manager has no breadcrumb crumb of its own above the categories, so the
	 * navigation entry is the only "way back" to the resource overview. Its menu lists the
	 * top level resource categories, which is why the source is set to the XFRM root here.
	 */
	protected static function getNavEntryCrumb(App $app, array $params): ?array
	{
		$entry = $params['selectedNavEntry'] ?? null;
		if (!is_array($entry) || empty($entry['href']))
		{
			return null;
		}

		$href = (string) $entry['href'];
		$source = '';
		$sourceId = 0;

		if (Registry::isAvailable(Registry::SOURCE_XFRM_CATEGORY))
		{
			$resourcesHref = self::normalizeUrl($app->router('public')->buildLink('resources'));
			if ($resourcesHref !== '' && self::normalizeUrl($href) === $resourcesHref)
			{
				$source = Registry::SOURCE_XFRM_CATEGORY;
				$sourceId = 0;
			}
		}

		return [
			'value'     => (string) ($entry['title'] ?? ''),
			'href'      => $href,
			'source'    => $source,
			'source_id' => $sourceId,
		];
	}

	/**
	 * Normalizes a breadcrumb list and types every crumb.
	 *
	 * XF\Template\Templater::breadcrumbs() keeps every key except value/href in the
	 * 'attributes' array, while getBreadcrumbs() reports node_id / resource_category_id next
	 * to them. Lifting those values here means the template reads $breadcrumb.source and
	 * $breadcrumb.source_id directly, and the menu is chosen by source instead of being
	 * guessed from the link.
	 *
	 * Sources:
	 *  - node          — a forum node crumb (XF\Entity\Node::getBreadcrumbs());
	 *  - xfrm_category — a resource category crumb (XFRM\Entity\Category::getBreadcrumbs());
	 *  - ''            — anything else (thread, member, resource); no menu.
	 *
	 * @param mixed $crumbs
	 *
	 * @return array
	 */
	protected static function normalizeCrumbs($crumbs): array
	{
		if (!is_array($crumbs))
		{
			return [];
		}

		$output = [];
		foreach ($crumbs AS $crumb)
		{
			if (!is_array($crumb))
			{
				continue;
			}

			$attributes = isset($crumb['attributes']) && is_array($crumb['attributes'])
				? $crumb['attributes']
				: [];

			$nodeId = (int) ($crumb['node_id'] ?? ($attributes['node_id'] ?? 0));
			$categoryId = (int) ($crumb['resource_category_id'] ?? ($attributes['resource_category_id'] ?? 0));

			// A crumb added by EntityCrumbs already knows its source; it must not be replaced
			// by the "no menu" fallback below.
			if (isset($crumb['source']) && (string) $crumb['source'] !== '')
			{
				$crumb['node_id'] = $nodeId;

				$output[] = $crumb;
				continue;
			}

			if ($categoryId > 0)
			{
				$source = Registry::SOURCE_XFRM_CATEGORY;
				$sourceId = $categoryId;
			}
			else if ($nodeId > 0)
			{
				$source = Registry::SOURCE_NODE;
				$sourceId = $nodeId;
			}
			else
			{
				$source = '';
				$sourceId = 0;
			}

			$crumb['node_id'] = $nodeId;
			$crumb['source'] = $source;
			$crumb['source_id'] = $sourceId;

			$output[] = $crumb;
		}

		return $output;
	}

	/**
	 * Drops the crumb of the current page: a crumb that links to the page being viewed would
	 * only link to itself.
	 *
	 * This is the only place that makes the decision, so the rule is the same everywhere:
	 *  - thread pages get no thread crumb (XF does not add one, nothing to drop);
	 *  - member profiles lose the username crumb on the first profile page and keep it on
	 *    page 2 and on profile sub-pages;
	 *  - resource pages lose the resource crumb, update/review pages keep it as a way back;
	 *  - category crumbs (node and XFRM) are always kept: a category page shows its own
	 *    category as the last crumb with its sub-categories in the menu.
	 *
	 * @param array $crumbs
	 *
	 * @return array
	 */
	protected static function removeCurrentPageCrumb(App $app, array $crumbs): array
	{
		$current = self::normalizeUrl($app->request()->getRequestUri());
		if ($current === '')
		{
			return $crumbs;
		}

		$output = [];
		foreach ($crumbs AS $crumb)
		{
			$source = (string) ($crumb['source'] ?? '');
			if ($source === Registry::SOURCE_NODE || $source === Registry::SOURCE_XFRM_CATEGORY)
			{
				$output[] = $crumb;
				continue;
			}

			$href = self::normalizeUrl((string) ($crumb['href'] ?? ''));
			if ($href !== '' && $href === $current)
			{
				continue;
			}

			$output[] = $crumb;
		}

		return $output;
	}

	/**
	 * Comparable form of a link: path only, no scheme/host, no query/fragment, no trailing
	 * slash. Values that cannot be compared (empty, non-http schemes) return ''.
	 */
	protected static function normalizeUrl(string $url): string
	{
		$url = trim($url);
		if ($url === '')
		{
			return '';
		}

		if (preg_match('#^[a-z][a-z0-9+.-]*://#i', $url))
		{
			$path = (string) parse_url($url, PHP_URL_PATH);
		}
		else if (strpos($url, '//') === 0)
		{
			$path = (string) parse_url('http:' . $url, PHP_URL_PATH);
		}
		else
		{
			$path = (string) parse_url($url, PHP_URL_PATH);
			if ($path === '')
			{
				$path = $url;
			}
		}

		$path = rawurldecode($path);
		$path = rtrim($path, '/');

		return $path === '' ? '/' : $path;
	}

	/**
	 * The container template name for this reply, without the template type prefix.
	 */
	protected static function resolveTemplateName(array $params, AbstractReply $reply): string
	{
		$template = (string) ($params['template'] ?? '');

		if ($template === '' && $reply instanceof View)
		{
			$template = (string) $reply->getTemplateName();
		}

		if (strpos($template, ':') !== false)
		{
			[$type, $template] = explode(':', $template, 2);
		}

		return strtolower(trim($template));
	}

	/**
	 * Whether breadcrumbs must be hidden for this template.
	 *
	 * The option holds template names only (comma or whitespace separated) and is parsed once
	 * per request. Request URI fragments are deliberately not supported: matching the URI by
	 * substring used to hide breadcrumbs on unrelated pages such as /threads/login-error.123/.
	 */
	protected static function isExcluded(string $template): bool
	{
		static $excluded = null;

		if ($excluded === null)
		{
			$excluded = [];

			$option = (string) (\XF::options()->ad90_breadcrumb_exclude_templates ?? '');
			foreach (preg_split('/[\s,]+/', strtolower($option), -1, PREG_SPLIT_NO_EMPTY) AS $name)
			{
				$excluded[$name] = true;
			}
		}

		return isset($excluded[$template]);
	}
}
