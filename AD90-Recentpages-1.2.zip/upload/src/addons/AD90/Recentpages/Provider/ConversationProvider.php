<?php

namespace AD90\Recentpages\Provider;

use XF\Entity\ConversationMaster;
use XF\Mvc\Reply\View;

/**
 * Провайдер типа «переписка». Определяет собеседника (единственного
 * получателя, отличного от текущего пользователя) и кладёт в params его
 * user_id (peer_id), а не ник: имя подставляется при выводе (см. TitleBuilder),
 * поэтому переименование собеседника сразу видно в чипе.
 *
 * title хранит сырое название переписки как запасное значение (групповая
 * переписка, удалённый собеседник и т. п.).
 */
class ConversationProvider extends BuiltinProvider
{
	public function match(string $viewClass, View $reply): ?array
	{
		$matched = parent::match($viewClass, $reply);
		if ($matched === null)
		{
			return null;
		}

		$params = $reply->getParams();
		$conversation = $params[$this->entityParam] ?? null;
		if (!$conversation instanceof ConversationMaster)
		{
			return $matched;
		}

		$peerId = $this->findPeerId($conversation);
		if ($peerId !== null)
		{
			$matched['params']['peer_id'] = $peerId;
		}

		return $matched;
	}

	/**
	 * id единственного собеседника (не текущего пользователя) или null, если
	 * собеседников больше одного либо определить нельзя.
	 *
	 * ConversationMaster::recipients содержит только «других» участников, без
	 * владельца переписки (он хранится в user_id). Поэтому владельца добавляем
	 * в набор кандидатов вручную — иначе получатель переписки видел в списке
	 * только самого себя и собеседник не определялся.
	 */
	protected function findPeerId(ConversationMaster $conversation): ?int
	{
		$viewerId = (int) \XF::visitor()->user_id;

		$peers = [];
		foreach ($conversation->recipients AS $recipient)
		{
			$userId = (int) ($recipient['user_id'] ?? 0);
			if ($userId && $userId !== $viewerId)
			{
				$peers[$userId] = true;
			}
		}

		$ownerId = (int) $conversation->user_id;
		if ($ownerId && $ownerId !== $viewerId)
		{
			$peers[$ownerId] = true;
		}

		if (count($peers) !== 1)
		{
			return null;
		}

		return (int) key($peers);
	}
}
