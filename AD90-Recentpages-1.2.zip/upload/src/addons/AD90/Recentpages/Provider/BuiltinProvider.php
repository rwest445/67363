<?php

namespace AD90\Recentpages\Provider;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Reply\View;

/**
 * Универсальный провайдер, описываемый конфигурацией: соответствие viewClass →
 * тип страницы, имя сущности в viewParams, префикс роута и имя поля заголовка.
 *
 * Покрывает встроенные типы (тема, профиль, статья помощи, ресурс, переписка).
 * Канонический URL строится из сущности, поэтому одна и та же страница получает
 * один и тот же URL и при SEO-ссылке, и при index.php?... — дублей нет.
 *
 * URL проходит Repository::canonicalizeUrl() для единообразия: всегда с ведущим /,
 * без хеша и служебных параметров, с учётом подкаталога форума.
 */
class BuiltinProvider implements ProviderInterface
{
	/** @var string */
	protected $type;

	/** @var string Ключ фразы с названием типа для опции ad90_types. */
	protected $titlePhrase;

	/** @var string[] viewClass'ы, которые распознаёт этот провайдер. */
	protected $viewClasses;

	/** @var string Ключ сущности в viewParams контроллера. */
	protected $entityParam;

	/** @var string Префикс роута для buildLink (например 'threads', 'members'). */
	protected $route;

	/** @var string Имя поля/геттера сущности, из которого берём заголовок. */
	protected $titleField;

	/**
	 * @param array $config ['type','title_phrase','view_classes','entity_param','route','title_field']
	 */
	public function __construct(array $config)
	{
		$this->type = $config['type'];
		$this->titlePhrase = $config['title_phrase'];
		$this->viewClasses = $config['view_classes'];
		$this->entityParam = $config['entity_param'];
		$this->route = $config['route'];
		$this->titleField = $config['title_field'];
	}

	public function getType(): string
	{
		return $this->type;
	}

	public function getTitlePhrase(): string
	{
		return $this->titlePhrase;
	}

	public function match(string $viewClass, View $reply): ?array
	{
		if (!in_array($viewClass, $this->viewClasses, true))
		{
			return null;
		}

		$params = $reply->getParams();
		$entity = $params[$this->entityParam] ?? null;

		if (!$entity instanceof Entity)
		{
			return null;
		}

		$title = (string) ($entity->{$this->titleField} ?? '');
		if (trim($title) === '')
		{
			return null;
		}

		$router = \XF::app()->router('public');
		// Относительный роут из сущности: детерминирован, canonicalizeUrl
		// приведёт его к канону. Canonical-роуты есть не для всех типов, поэтому
		// берём обычный публичный роут (стабильный хеш важнее SEO-формы ссылки).
		$url = $router->buildLink($this->route, $entity);

		return [
			'title' => $title,
			'url' => $url,
			'params' => $this->buildParams($entity),
		];
	}

	/**
	 * Минимальные параметры для сборки заголовка/иконки при выводе и для будущей
	 * интеграции (например id сущности). Берём значения первичного ключа через
	 * штатный getIdentifierValues(): getStructure() в XF 2.3 статический и от
	 * экземпляра не вызывается.
	 */
	protected function buildParams(Entity $entity): array
	{
		return $entity->getIdentifierValues() ?: [];
	}
}
