<?php

namespace AD90\Recentpages\Provider;

/**
 * Реестр встроенных провайдеров типов страниц.
 *
 * viewClass'ы и ключи viewParams сверены с исходниками XenForo 2.3:
 *   XF:Thread\View (+ типы)        → param 'thread'       → роут threads       → title
 *   XF:Member\View                 → param 'user'         → роут members       → username
 *   XF:Member\Notable              → (нет сущности)       → роут members       → заголовок
 *   XF:Help\Page                   → param 'page'         → роут help          → title
 *   XF:Conversation\View           → param 'conversation' → роут conversations → title
 *   XFRM:ResourceItem\View         → param 'resource'     → роут resources     → title
 *
 * Списки/формы/рефреш (Listing, Reply, Edit, Refresh, Preview …) намеренно не
 * входят: это не контентные страницы. Белый список, а не чёрный.
 *
 * Сторонние типы добавляются через код-событие ad90_recentpages_collect.
 */
class Registry
{
	/**
	 * @return ProviderInterface[] Массив провайдеров по типу.
	 */
	public static function all(): array
	{
		$definitions = [
			[
				'type' => 'thread',
				'title_phrase' => 'ad90_type_thread',
				// Просмотр темы и все типы тем (опрос, вопрос, статья, предложение).
				'view_classes' => [
					'XF:Thread\View',
					'XF:Thread\ViewTypePoll',
					'XF:Thread\ViewTypeQuestion',
					'XF:Thread\ViewTypeArticle',
					'XF:Thread\ViewTypeSuggestion',
				],
				'entity_param' => 'thread',
				'route' => 'threads',
				'title_field' => 'title',
			],
			[
				'type' => 'member',
				'title_phrase' => 'ad90_type_member',
				'view_classes' => ['XF:Member\View'],
				'entity_param' => 'user',
				'route' => 'members',
				'title_field' => 'username',
			],
			[
				'type' => 'notable',
				'title_phrase' => 'ad90_type_notable',
				'view_classes' => ['XF:Member\Notable'],
				'entity_param' => '',
				'route' => 'members',
				'title_field' => '',
			],
			[
				'type' => 'help',
				'title_phrase' => 'ad90_type_help',
				'view_classes' => ['XF:Help\Page'],
				'entity_param' => 'page',
				'route' => 'help',
				'title_field' => 'title',
			],
			[
				'type' => 'resource',
				'title_phrase' => 'ad90_type_resource',
				'view_classes' => ['XFRM:ResourceItem\View'],
				'entity_param' => 'resource',
				'route' => 'resources',
				'title_field' => 'title',
			],
			[
				'type' => 'conversation',
				'title_phrase' => 'ad90_type_conversation',
				'view_classes' => ['XF:Conversation\View'],
				'entity_param' => 'conversation',
				'route' => 'conversations',
				'title_field' => 'title',
			],
		];

		$specialClasses = [
			// Переписка: определяет собеседника и пишет его id в params.
			'conversation' => 'AD90\\Recentpages\\Provider\\ConversationProvider',
			// Сводный список участников: заголовок не из поля сущности.
			'notable' => 'AD90\\Recentpages\\Provider\\NotableProvider',
		];

		$providers = [];
		foreach ($definitions AS $definition)
		{
			$type = $definition['type'];
			$class = $specialClasses[$type] ?? 'AD90\\Recentpages\\Provider\\BuiltinProvider';
			$provider = new $class($definition);
			$providers[$provider->getType()] = $provider;
		}

		return $providers;
	}

	/**
	 * Все известные типы с названиями для опции ad90_types: встроенные плюс
	 * добавленные сторонними аддонами через ad90_recentpages_collect.
	 *
	 * @return array<string, string> тип → фраза названия
	 */
	public static function typeTitles(): array
	{
		$providers = self::all();
		\XF::app()->fire('ad90_recentpages_collect', [&$providers]);

		$titles = [];
		foreach ($providers AS $provider)
		{
			if (!$provider instanceof ProviderInterface)
			{
				continue;
			}

			$titles[$provider->getType()] = $provider->getTitlePhrase();
		}

		return $titles;
	}
}
