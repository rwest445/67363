<?php

namespace AD90\Recentpages\Provider;

use XF\Entity\User;

/**
 * Собирает заголовок чипа по типу и params.
 *
 * Для типа conversation — «Переписки | Ник»: ник берётся из карты пользователей
 * (peer_id → username), которую загружает вызывающий код одним запросом на весь
 * список. Если собеседник не найден (удалён) или переписка групповая —
 * «Переписки | {title}».
 *
 * Записи, сохранённые до 1.1.15, содержат ник в params['peer']; он используется
 * как запасное значение, пока нет peer_id.
 *
 * Язык определяется через \XF::phrase(), поэтому заголовок меняется автоматически
 * при смене языка без перезахода в переписку.
 */
class TitleBuilder
{
	/**
	 * Собирает финальный заголовок.
	 *
	 * @param string $type Тип страницы.
	 * @param string $title Сырой заголовок (title сущности).
	 * @param array $params Параметры (params из match).
	 * @param array<int, string> $users Карта peer_id → username для переписок.
	 * @return string Заголовок для чипа.
	 */
	public static function build(string $type, string $title, array $params, array $users = []): string
	{
		if ($type === 'conversation')
		{
			$name = null;

			$peerId = $params['peer_id'] ?? null;
			if ($peerId !== null && isset($users[(int) $peerId]))
			{
				$name = (string) $users[(int) $peerId];
			}
			else if ($peerId === null && isset($params['peer']) && is_string($params['peer']))
			{
				// Запись, сохранённая до 1.1.15: ника в params больше нет, но имя
				// из старой записи ещё актуально как запасное значение.
				$name = $params['peer'];
			}

			if ($name !== null && $name !== '')
			{
				return (string) \XF::phrase('ad90_title_conversation', ['name' => $name]);
			}

			// Групповая переписка или собеседник не найден — fallback на сырой заголовок.
			return (string) \XF::phrase('ad90_title_conversation_fallback', ['title' => $title]);
		}

		return $title;
	}

	/**
	 * Загружает одним запросом всех собеседников из списка записей.
	 *
	 * @param iterable $pages Записи истории (сущности с params и type).
	 * @return array<int, string> Карта peer_id → username.
	 */
	public static function loadPeerUsers($pages): array
	{
		$ids = [];
		foreach ($pages AS $page)
		{
			if ((string) $page->type !== 'conversation')
			{
				continue;
			}

			$params = $page->params ?: [];
			$peerId = isset($params['peer_id']) ? (int) $params['peer_id'] : 0;
			if ($peerId > 0)
			{
				$ids[$peerId] = $peerId;
			}
		}

		if (!$ids)
		{
			return [];
		}

		$users = \XF::app()->repository('XF:User')->getUsersByIdsOrdered(array_values($ids));

		$map = [];
		foreach ($users AS $user)
		{
			if ($user instanceof User)
			{
				$map[(int) $user->user_id] = (string) $user->username;
			}
		}

		return $map;
	}
}
