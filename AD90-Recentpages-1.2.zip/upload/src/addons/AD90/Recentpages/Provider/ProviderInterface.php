<?php

namespace AD90\Recentpages\Provider;

use XF\Mvc\Reply\View;

/**
 * Провайдер типа страниц для блока недавних страниц.
 *
 * Провайдер решает по ответу контроллера (Reply\View), является ли страница
 * контентом его типа, и если да — возвращает данные для записи: тип, параметры
 * для сборки заголовка при выводе, сам заголовок (сырой, без локализованных
 * префиксов) и канонический относительный URL.
 *
 * Сторонний тип добавляется подпиской на код-событие ad90_recentpages_collect:
 * в массив провайдеров добавляется объект, реализующий этот интерфейс.
 */
interface ProviderInterface
{
	/**
	 * Идентификатор типа (совпадает со значением колонки type и ключом опции
	 * ad90_types). Например: thread, member, conversation.
	 */
	public function getType(): string;

	/**
	 * Ключ фразы с названием типа для администратора (опция ad90_types).
	 * Встроенные провайдеры возвращают ad90_type_*.
	 */
	public function getTitlePhrase(): string;

	/**
	 * Пытается распознать свою страницу по ответу контроллера.
	 *
	 * @param string $viewClass Значение Reply\View::getViewClass(), напр. 'XF:Thread\View'.
	 * @param View   $reply     Ответ контроллера (доступ к getParams()).
	 *
	 * @return array|null null — страница не этого типа. Иначе массив:
	 *   ['title' => string, 'url' => string, 'params' => array]
	 */
	public function match(string $viewClass, View $reply): ?array;
}
