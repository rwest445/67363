<?php

namespace AD90\Recentpages;

use XF\Entity\User;

/**
 * Единая точка доступа к лимитам и настройкам блока недавних страниц.
 *
 * Все пределы (размер истории, число закреплённых, включённые типы) читаются
 * только здесь — чтобы JS, PHP-контроллер и слушатель записи не размечали
 * константы в разных местах.
 */
class Limits
{
	/** Значение по умолчанию, если ни право, ни опция не заданы. */
	const DEFAULT_MAX_ITEMS = 10;
	const DEFAULT_MAX_PINNED = 10;

	/**
	 * Максимум незакреплённых страниц в истории для пользователя.
	 * Право maxItems (0 → значение опции ad90_maxItems).
	 */
	public static function maxItems(User $user): int
	{
		$byPermission = (int) $user->hasPermission('ad90RecentPages', 'maxItems');
		$max = $byPermission === -1 ? Repository\RecentPage::HARD_LIMIT : ($byPermission > 0 ? $byPermission : self::optionInt('ad90_maxItems', self::DEFAULT_MAX_ITEMS));

		return Repository\RecentPage::clampMax($max);
	}

	/**
	 * Максимум закреплённых страниц. Право maxPinned (0 → значение опции
	 * ad90_maxPinned).
	 */
	public static function maxPinned(User $user): int
	{
		$byPermission = (int) $user->hasPermission('ad90RecentPages', 'maxPinned');
		$max = $byPermission === -1 ? Repository\RecentPage::HARD_LIMIT : ($byPermission > 0 ? $byPermission : self::optionInt('ad90_maxPinned', self::DEFAULT_MAX_PINNED));

		return max(0, min($max, Repository\RecentPage::HARD_LIMIT));
	}

	/**
	 * Читает числовую опцию, не падая при её отсутствии в xf_option.
	 *
	 * XF\Options::offsetGet() в debug-режиме бросает ErrorException на незнакомый
	 * ключ, поэтому прямое обращение через -> превращало отсутствующую опцию
	 * (например, когда _data/options.xml не импортирован) в HTTP 500 на любом
	 * запросе истории.
	 */
	protected static function optionInt(string $optionId, int $default): int
	{
		$options = \XF::options();

		if (!isset($options[$optionId]))
		{
			return $default;
		}

		return (int) $options[$optionId];
	}

	/**
	 * Читает опцию-массив, не падая при её отсутствии в xf_option.
	 */
	protected static function optionArray(string $optionId): array
	{
		$options = \XF::options();

		if (!isset($options[$optionId]))
		{
			return [];
		}

		$value = $options[$optionId];

		return is_array($value) ? $value : [];
	}

	/**
	 * Включённые типы страниц (опция ad90_types, массив ключ→значение).
	 *
	 * Опция строится динамически из всех зарегистрированных провайдеров, включая
	 * добавленные через код-событие ad90_recentpages_collect. Тип, которого в
	 * опции ещё нет (новый, админ его не сохранял), считается включённым.
	 *
	 * @return string[]
	 */
	public static function enabledTypes(): array
	{
		$types = self::optionArray('ad90_types');
		$types = is_array($types) ? $types : [];

		$enabled = [];
		foreach ($types AS $type => $on)
		{
			if (!empty($on))
			{
				$enabled[] = (string) $type;
			}
		}

		// Типы, отсутствующие в сохранённом значении (новый провайдер), включены.
		foreach (Provider\Registry::typeTitles() AS $type => $phrase)
		{
			if (!array_key_exists($type, $types))
			{
				$enabled[] = (string) $type;
			}
		}

		return $enabled;
	}

	public static function isTypeEnabled(string $type): bool
	{
		$types = self::optionArray('ad90_types');
		$types = is_array($types) ? $types : [];

		if (array_key_exists($type, $types))
		{
			return !empty($types[$type]);
		}

		// Ключа нет: тип новый (его добавили после сохранения опции) — включён.
		// Ключи удалённых аддонов остаются в опции, но никем не запрашиваются.
		return true;
	}
}
