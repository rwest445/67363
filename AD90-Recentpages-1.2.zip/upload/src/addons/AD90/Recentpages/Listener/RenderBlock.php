<?php

namespace AD90\Recentpages\Listener;

use AD90\Recentpages\Limits;
use AD90\Recentpages\Provider\TitleBuilder;
use XF\Template\Templater;

/**
 * Слушатель templater_template_pre_render (context public:ad90_recent_pages).
 *
 * Передаёт начальный список недавних страниц в шаблон как параметр, чтобы блок
 * отрисовывался сразу на сервере — чипы видны с первого кадра, без вспышки
 * после перезагрузки. Единственное место, где шаблон получает содержимое истории.
 *
 * Имена собеседников для переписок подгружаются одним запросом на весь список
 * (TitleBuilder::loadPeerUsers), а не по запросу на запись.
 */
class RenderBlock
{
	public static function preRenderTemplate(
		Templater $templater,
		string &$type,
		string &$template,
		array &$params
	): void {
		$visitor = \XF::visitor();
		// Блок не будет отрисован (гость / нет права / пользователь скрыл блок) —
		// не грузим историю.
		if (!$visitor->user_id
			|| !$visitor->hasPermission('ad90RecentPages', 'view')
			|| !$visitor->Option->ad90_show_recent_pages
		)
		{
			$params['ad90RpItems'] = [];
			$params['ad90RpMax'] = 0;
			$params['ad90RpMaxPin'] = 0;

			return;
		}

		/** @var \AD90\Recentpages\Repository\RecentPage $repo */
		$repo = \XF::app()->repository('AD90\Recentpages:RecentPage');

		$pages = $repo->findByUser((int) $visitor->user_id);
		$peerUsers = TitleBuilder::loadPeerUsers($pages);

		$items = [];
		foreach ($pages AS $page)
		{
			$items[] = [
				'url' => $page->url,
				'type' => $page->type,
				'title' => $page->buildDisplayTitle($peerUsers),
				'pinned' => (bool) $page->pinned,
			];
		}

		$params['ad90RpItems'] = $items;
		$params['ad90RpMax'] = Limits::maxItems($visitor);
		$params['ad90RpMaxPin'] = Limits::maxPinned($visitor);
		$params['ad90RpPhrases'] = self::jsPhrases();
	}

	/**
	 * Переводы, которые нужны клиентскому JS. Собираются в JSON для штатного
	 * скрипта js-extraPhrases (XF подмешивает их в XF.phrases, и JS читает их
	 * через XF.phrase()). JSON_HEX_* гарантируют безопасную вставку внутрь
	 * <script> (никаких «</script>» и голых кавычек).
	 */
	public static function jsPhrases(): string
	{
		$phrases = [
			'ad90_remove',
			'ad90_pin',
			'ad90_unpin',
			'ad90_msg_cleared',
			'ad90_msg_hidden',
			'ad90_undo',
			'ad90_pin_limit',
		];

		$out = [];
		foreach ($phrases AS $name)
		{
			$out[$name] = (string) \XF::phrase($name);
		}

		return json_encode(
			$out,
			JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE
		);
	}
}
