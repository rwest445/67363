<?php

namespace AD90\Recentpages\Repository;

use XF\Mvc\Entity\Repository;
use XF\Util\Str;

/**
 * Недавно посещённые страницы пользователя.
 *
 * Хранятся в отдельной таблице xf_ad90_recentpages_page (по строке на страницу),
 * а не в JSON-колонке xf_user_option: это снимает блокировку строки Option при
 * каждой навигации и позволяет чистить записи по пользователю и по возрасту.
 *
 * Порядок: единое поле display_order. Закреплённые всегда показываются первыми,
 * их порядок задаёт пользователь. Визит поднимает незакреплённую запись наверх,
 * закреплённые при визите не перемещаются.
 *
 * Сущность: AD90\Recentpages\Entity\RecentPage (shortName 'AD90\Recentpages:RecentPage').
 */
class RecentPage extends Repository
{
	/** Жёсткий предел хранимых записей на пользователя, даже если права позволяют больше. */
	const HARD_LIMIT = 100;

	/** Минимальный интервал между повторными записями визита одной страницы, сек. */
	const RECORD_THROTTLE = 30;

	const ENTITY = 'AD90\Recentpages:RecentPage';

	/** Ограничивает произвольное значение размера истории валидным диапазоном. */
	public static function clampMax(int $max): int
	{
		return max(0, min($max, self::HARD_LIMIT));
	}

	/**
	 * Возвращает записи пользователя в порядке вывода:
	 * закреплённые (по display_order), затем остальные (по display_order).
	 *
	 * @return \XF\Mvc\Entity\AbstractCollection
	 */
	public function findByUser(int $userId)
	{
		if (!$userId)
		{
			return new \XF\Mvc\Entity\ArrayCollection([]);
		}

		return $this->finder(self::ENTITY)
			->where('user_id', $userId)
			->order([['pinned', 'DESC'], ['display_order', 'ASC']])
			->fetch();
	}

	/**
	 * Записывает визит. Существующая незакреплённая запись поднимается наверх и
	 * обновляет заголовок/параметры/дату; закреплённая — только дату, заголовок и
	 * параметры. Новая создаётся наверху среди незакреплённых.
	 *
	 * @param array $params Параметры для сборки заголовка при выводе.
	 * @return \AD90\Recentpages\Entity\RecentPage|null null если запись не требуется
	 *        (троттлинг / пустой заголовок / невалидный URL).
	 */
	public function recordVisit(
		int $userId,
		string $url,
		string $type,
		string $title,
		array $params = [],
		int $max = 10
	) {
		$title = $this->cleanTitle($title);
		if ($title === '')
		{
			return null;
		}

		$url = self::canonicalizeUrl($url);
		if (!self::isValidUrl($url))
		{
			return null;
		}

		$hash = self::hashUrlFor($url);

		$existing = $this->em->find(self::ENTITY, [$userId, $hash]);

		// Троттлинг: не пишем повторно, если визит был только что. Закреплённой
		// странице он тоже нужен — иначе клик по закреплённому чипу накручивал бы
		// last_visit_date и она «уезжала» бы вверх при откреплении.
		if ($existing && $existing->last_visit_date >= \XF::$time - self::RECORD_THROTTLE)
		{
			return null;
		}

		// Порядок «наверх» нужен только незакреплённым. Для существующей
		// закреплённой записи порядок не меняется, поэтому nextTopOrder не
		// вызываем: это лишний запрос (а при min = 1 — ещё и сдвиг всей группы).
		$isPinned = $existing && $existing->pinned;
		$order = $isPinned ? (int) $existing->display_order : $this->nextTopOrder($userId);
		$paramsJson = json_encode($params, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

		// Атомарная upsert-запись закрывает гонку двух вкладок: обе делают один и
		// тот же запрос, PK (user_id, url_hash) не даёт дубля, вторая вкладка
		// уходит в ветку UPDATE вместо падения на duplicate key.
		$this->db()->query(
			'INSERT INTO xf_ad90_recentpages_page
				(user_id, url_hash, url, type, params, title, pinned, display_order, last_visit_date)
			 VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)
			 ON DUPLICATE KEY UPDATE
				type = VALUES(type),
				params = VALUES(params),
				title = VALUES(title),
				last_visit_date = VALUES(last_visit_date),
				display_order = IF(pinned = 0, VALUES(display_order), display_order)',
			[
				$userId,
				$hash,
				substr($url, 0, 255),
				$type,
				$paramsJson,
				$title,
				$order,
				\XF::$time,
			]
		);

		$this->trim($userId, $max);

		// Освежаем сущность из identity map, чтобы вернуть актуальные значения.
		// В XF нет Manager::refresh(), поэтому синхронизируем поля вручную теми же
		// данными, что записали в SQL (params — массив, не JSON-строка).
		if ($existing)
		{
			$existing->type = $type;
			$existing->params = $params;
			$existing->title = $title;
			$existing->last_visit_date = \XF::$time;
			if (!$existing->pinned)
			{
				$existing->display_order = $order;
			}

			return $existing;
		}

		return $this->em->find(self::ENTITY, [$userId, $hash]);
	}

	/**
	 * Закрепляет/открепляет страницу.
	 *
	 * При откреплении страница возвращается в ленту незакреплённых на «своё»
	 * место — по времени последнего захода, а не наверх: иначе после открепления
	 * она оказывалась бы там, где стояла среди закреплённых.
	 *
	 * @return \AD90\Recentpages\Entity\RecentPage|string|null Сущность при успехе,
	 *        строку 'pin_limit' при превышении лимита закреплённых, null если записи нет.
	 */
	public function setPinned(int $userId, string $url, bool $pinned, int $maxPin, int $max)
	{
		$entity = $this->findEntity($userId, $url);
		if (!$entity)
		{
			return null;
		}

		if ($pinned && !$entity->pinned && $this->countPinned($userId) >= $maxPin)
		{
			return 'pin_limit';
		}

		$wasPinned = $entity->pinned;
		$entity->pinned = $pinned;
		if ($pinned)
		{
			$entity->display_order = $this->nextTopOrder($userId, true);
		}
		else if ($wasPinned)
		{
			$entity->display_order = $this->unpinnedSlotFor($userId, (int) $entity->last_visit_date);
		}
		$entity->save();

		$this->trim($userId, $max);

		return $entity;
	}

	public function remove(int $userId, string $url): bool
	{
		$entity = $this->findEntity($userId, $url);
		if (!$entity)
		{
			return false;
		}

		$entity->delete();

		return true;
	}

	/** Очистка оставляет только закреплённые страницы. */
	public function clear(int $userId): void
	{
		$this->db()->delete(
			'xf_ad90_recentpages_page',
			'user_id = ? AND pinned = 0',
			$userId
		);
	}

	/**
	 * Применяет новый порядок после перетаскивания.
	 * Неизвестные URL игнорируются; переписывается display_order по позиции.
	 *
	 * @param string[] $urls Канонические URL в новом порядке.
	 */
	public function setOrder(int $userId, array $urls): void
	{
		$existing = $this->finder(self::ENTITY)
			->where('user_id', $userId)
			->fetch();

		$byHash = [];
		foreach ($existing AS $entity)
		{
			$byHash[$entity->url_hash] = $entity;
		}

		$order = 0;
		foreach ($urls AS $url)
		{
			if (!is_string($url))
			{
				continue;
			}

			$hash = $this->hashUrl($url);
			if (isset($byHash[$hash]))
			{
				$byHash[$hash]->display_order = ++$order;
				$byHash[$hash]->save();
				unset($byHash[$hash]);
			}
		}

		// Оставшиеся (не попавшие в список) дописываем в конец.
		foreach ($byHash AS $entity)
		{
			$entity->display_order = ++$order;
			$entity->save();
		}
	}

	// ---------------------------------------------------------------------

	protected function findEntity(int $userId, string $url)
	{
		return $this->em->find(self::ENTITY, [$userId, $this->hashUrl($url)]);
	}

	protected function countPinned(int $userId): int
	{
		return $this->finder(self::ENTITY)
			->where('user_id', $userId)
			->where('pinned', '=', 1)
			->total();
	}

	/**
	 * Следующий порядковый номер для «поднятия наверх»: минимум внутри той же
	 * группы (закреплённые / незакреплённые) минус 1.
	 *
	 * Группы нумеруются независимо: закреплённые всегда выводятся первыми, их
	 * порядок задаёт пользователь, и он не должен конфликтовать с порядком
	 * незакреплённых. Если считать минимум по чужой группе, все закреплённые
	 * получали бы один и тот же номер и их взаимный порядок становился бы
	 * недетерминированным.
	 *
	 * display_order — UINT, отрицательные значения недопустимы. Поэтому когда
	 * минимум дошёл до 1, вся группа сдвигается вверх на единицу (1..N → 2..N+1)
	 * одним запросом, и сверху освобождается 1. Сдвиг, а не перенумерация: не
	 * нужно читать строки в PHP и делать по UPDATE на каждую.
	 */
	protected function nextTopOrder(int $userId, bool $pinned = false): int
	{
		$min = $this->db()->fetchOne(
			'SELECT MIN(display_order) FROM xf_ad90_recentpages_page WHERE user_id = ? AND pinned = ?',
			[$userId, $pinned ? 1 : 0]
		);

		if ($min === null || $min === false)
		{
			return 1;
		}

		$min = (int) $min;

		if ($min > 1)
		{
			return $min - 1;
		}

		// Минимум = 1: сдвигаем всю группу вверх, освобождая 1.
		$this->db()->query(
			'UPDATE xf_ad90_recentpages_page
			 SET display_order = display_order + 1
			 WHERE user_id = ? AND pinned = ?',
			[$userId, $pinned ? 1 : 0]
		);

		return 1;
	}

	/**
	 * Позиция для страницы, которую открепляют: место среди незакреплённых по
	 * времени последнего захода (свежие выше).
	 *
	 * Незакреплённые идут от свежей к старой, поэтому берём первую запись, у
	 * которой last_visit_date меньше нашего (она старее) — откреплённая встаёт
	 * перед ней. Если таких нет, она встаёт в конец группы. Равное время
	 * трактуется как «наша страница старее» — то есть встаёт после записи с тем
	 * же временем.
	 *
	 * Освободившееся место получается сдвигом display_order у найденной и всех
	 * последующих записей на +1 одним запросом (как в nextTopOrder), без
	 * перенумерации строк по одной. В группе незакреплённых дублей не остаётся.
	 */
	protected function unpinnedSlotFor(int $userId, int $lastVisitDate): int
	{
		$slot = $this->db()->fetchOne(
			'SELECT display_order FROM xf_ad90_recentpages_page
			 WHERE user_id = ? AND pinned = 0 AND last_visit_date < ?
			 ORDER BY display_order ASC
			 LIMIT 1',
			[$userId, $lastVisitDate]
		);

		if ($slot === null || $slot === false)
		{
			// Все остальные новее (или равны) — встаём в конец группы.
			$max = $this->db()->fetchOne(
				'SELECT MAX(display_order) FROM xf_ad90_recentpages_page WHERE user_id = ? AND pinned = 0',
				[$userId]
			);

			return ($max === null || $max === false) ? 1 : (int) $max + 1;
		}

		$slot = (int) $slot;

		// Освобождаем место: эта и все последующие записи сдвигаются вниз.
		$this->db()->query(
			'UPDATE xf_ad90_recentpages_page
			 SET display_order = display_order + 1
			 WHERE user_id = ? AND pinned = 0 AND display_order >= ?',
			[$userId, $slot]
		);

		return $slot;
	}

	/** Оставляет не больше $max незакреплённых записей (самые старые удаляются). */	protected function trim(int $userId, int $max): void
	{
		$max = max(1, min($max, self::HARD_LIMIT));

		// Считаем количество незакреплённых.
		$count = $this->db()->fetchOne(
			'SELECT COUNT(*) FROM xf_ad90_recentpages_page WHERE user_id = ? AND pinned = 0',
			$userId
		);

		if ($count <= $max)
		{
			return;
		}

		// Удаляем лишние — самые старые. Меньший display_order = выше в списке,
		// поэтому старые имеют БОЛЬШИЙ порядок и удаляются по DESC.
		// limit() добавляет LIMIT к запросу, параметры передаются отдельно.
		$delete = (int) $count - $max;
		$this->db()->query(
			$this->db()->limit(
				'DELETE FROM xf_ad90_recentpages_page
				 WHERE user_id = ? AND pinned = 0
				 ORDER BY display_order DESC',
				$delete
			),
			[$userId]
		);
	}

	protected function hashUrl(string $url): string
	{
		return self::hashUrlFor($url);
	}

	/**
	 * Удаляет незакреплённые записи, не посещавшиеся с момента $cutoff.
	 * Используется ночной cron-задачей.
	 *
	 * @return int Количество удалённых строк.
	 */
	public function deleteOlderThan(int $cutoff): int
	{
		return $this->db()->delete(
			'xf_ad90_recentpages_page',
			'pinned = 0 AND last_visit_date < ?',
			$cutoff
		);
	}

	/** Единый хеш канонического URL (используется и при миграции из Setup). */
	public static function hashUrlFor(string $url): string
	{
		return md5($url);
	}

	protected function cleanTitle(string $title): string
	{
		$title = preg_replace('/\s+/u', ' ', trim($title));

		return Str::substr($title, 0, 190);
	}

	/**
	 * Адрес форума из настроек: опция boardUrl, при её отсутствии — config.php.
	 */
	protected static function boardUrl(): string
	{
		$app = \XF::app();
		$boardUrl = (string) $app->options()->boardUrl;
		if ($boardUrl === '')
		{
			$boardUrl = (string) $app->config('board_url');
		}

		return $boardUrl;
	}

	/**
	 * Базовый путь форума (подкаталог) от корня сайта, без ведущего и завершающего
	 * слэша: '' для форума в корне, 'forum' для http://host/forum/.
	 *
	 * Адрес форума хранится в опции boardUrl; config('board_url') заполняется
	 * только при переопределении в config.php и обычно пуст, поэтому опция —
	 * основной источник.
	 */
	public static function basePath(): string
	{
		$u = parse_url(self::boardUrl());
		$path = isset($u['path']) ? trim($u['path'], '/') : '';

		return $path === '' ? '' : '/' . $path;
	}

	/**
	 * Приводит URL к каноническому абсолютному пути от корня сайта (всегда с
	 * ведущим / и с учётом подкаталога форума), чтобы одна страница не попадала
	 * в историю дважды. Единственное место нормализации URL в проекте.
	 *
	 * Форма совпадает с location.pathname, поэтому JS может сравнивать текущую
	 * страницу с сохранённым URL без своей нормализации.
	 *
	 * Входные формы: SEO-относительная ('threads/x.2034/'), SEO с подкаталогом
	 * ('forum/threads/x.2034/'), абсолютная ('https://host/threads/x.2034/'),
	 * non-SEO ('index.php?threads/x.2034/&page=2'), non-SEO в подкаталоге
	 * ('/forum/index.php?threads/x.2034/').
	 */
	public static function canonicalizeUrl(string $url): string
	{
		$base = self::basePath(); // '' или '/forum'

		// 0. Абсолютный URL чужого хоста не может быть страницей этого форума:
		// возвращаем как есть, чтобы isValidUrl() его отсеял. Иначе от него
		// остался бы только путь и внешняя ссылка стала бы локальной.
		if (preg_match('#^https?://#i', $url))
		{
			$self = parse_url((string) self::boardUrl());
			$that = parse_url($url);
			$selfHost = strtolower($self['host'] ?? '');
			$thatHost = strtolower($that['host'] ?? '');
			if ($thatHost !== '' && $selfHost !== '' && $thatHost !== $selfHost)
			{
				return $url;
			}
		}

		// 1. Убираем hash.
		$hashPos = strpos($url, '#');
		if ($hashPos !== false)
		{
			$url = substr($url, 0, $hashPos);
		}

		// 2. Разворачиваем non-SEO (index.php?route&params) в путь + query.
		$query = '';
		$phpPos = strpos($url, 'index.php?');
		if ($phpPos !== false)
		{
			$prefix = substr($url, 0, $phpPos); // '', '/', '/forum/', 'https://host/forum/'
			$tail = substr($url, $phpPos + 10); // 'threads/x.2034/&page=2'

			// Из prefix убираем схему+хост, оставляем путь (подкаталог).
			if (preg_match('#^https?://#i', $prefix))
			{
				$p = parse_url($prefix);
				$prefix = isset($p['path']) ? $p['path'] : '';
			}

			// В non-SEO параметры идут после первого &: route & page=2 & ...
			$ampPos = strpos($tail, '&');
			if ($ampPos !== false)
			{
				$route = substr($tail, 0, $ampPos);
				$query = substr($tail, $ampPos + 1);
			}
			else
			{
				$route = $tail;
			}

			$url = rtrim($prefix, '/') . '/' . ltrim($route, '/');
		}
		else
		{
			// 3. SEO / относительный путь. У абсолютного убираем схему+хост.
			if (preg_match('#^https?://#i', $url))
			{
				$p = parse_url($url);
				$url = isset($p['path']) ? $p['path'] : '/';
				$query = isset($p['query']) ? $p['query'] : '';
			}
			else
			{
				$queryPos = strpos($url, '?');
				if ($queryPos !== false)
				{
					$query = substr($url, $queryPos + 1);
					$url = substr($url, 0, $queryPos);
				}
			}
		}

		// 4. Ведущий слэш + базовый путь форума (если ещё не учтён).
		$url = '/' . ltrim($url, '/');
		$baseTrim = ltrim($base, '/');
		if ($baseTrim !== '' && strpos(ltrim($url, '/'), $baseTrim . '/') !== 0 && ltrim($url, '/') !== $baseTrim)
		{
			$url = '/' . $baseTrim . $url;
		}

		// 5. Фильтруем query: служебные XF-параметры и номер страницы не меняют содержимое.
		if ($query !== '')
		{
			$keep = [];
			foreach (explode('&', $query) AS $part)
			{
				if ($part === '')
				{
					continue;
				}

				$key = explode('=', $part, 2)[0];
				if ($key === 'page' || $key === '_debug' || strpos($key, '_xf') === 0)
				{
					continue;
				}

				$keep[] = $part;
			}
			$query = implode('&', $keep);
		}

		// 6. SEF-пагинация (/page-2/) не меняет страницу.
		$url = preg_replace('#/page-\d+/?$#', '', $url);
		$url = rtrim($url, '/');

		if ($url === '')
		{
			$url = '/';
		}
		else if (!preg_match('#\.(php|rss|json|xml|html?|txt|css|js|png|jpe?g|gif|svg|webp|ico|woff2?)$#i', $url))
		{
			$url .= '/';
		}

		return $query !== '' ? $url . '?' . $query : $url;
	}

	public static function isValidUrl(string $url): bool
	{
		if ($url === '' || strlen($url) > 255)
		{
			return false;
		}

		// только локальные пути от корня: с ведущим /, без схемы, без
		// протокол-относительных ссылок (//host) и без обратных слэшей/управляющих
		if ($url[0] !== '/' || (isset($url[1]) && $url[1] === '/'))
		{
			return false;
		}

		return strpos($url, '\\') === false && !preg_match('/[\x00-\x1F\x7F]/', $url);
	}
}
