<?php

namespace AD90\Recentpages\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * Одна недавно посещённая страница пользователя.
 *
 * @property int $user_id
 * @property string $url_hash Хеш канонического URL (часть составного PK)
 * @property string $url Канонический путь (относительный, начинается с /)
 * @property string $type Тип контента (thread, member, conversation, ...)
 * @property array $params Параметры для сборки заголовка/иконки при выводе
 * @property string $title Сырой заголовок сущности (без локализованных префиксов)
 * @property bool $pinned Закреплена ли страница
 * @property int $display_order Ручной порядок (перетаскивание)
 * @property int $last_visit_date Дата последнего визита
 */
class RecentPage extends Entity
{
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_ad90_recentpages_page';
		$structure->shortName = 'AD90\Recentpages:RecentPage';
		$structure->primaryKey = ['user_id', 'url_hash'];

		$structure->columns = [
			'user_id' => ['type' => self::UINT, 'required' => true],
			'url_hash' => ['type' => self::STR, 'maxLength' => 32, 'required' => true],
			'url' => ['type' => self::STR, 'maxLength' => 255, 'required' => true],
			'type' => ['type' => self::STR, 'maxLength' => 40, 'required' => true],
			'params' => ['type' => self::JSON_ARRAY, 'default' => []],
			'title' => ['type' => self::STR, 'maxLength' => 190, 'required' => true],
			'pinned' => ['type' => self::BOOL, 'default' => false],
			'display_order' => ['type' => self::UINT, 'default' => 0],
			'last_visit_date' => ['type' => self::UINT, 'default' => \XF::$time],
		];

		$structure->relations = [
			'User' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
		];

		$structure->defaultWith = [];

		return $structure;
	}

	/**
	 * Локализованный заголовок для отображения в чипе. Делегирует общей функции
	 * Provider\TitleBuilder::build(); карту пользователей (peer_id → username)
	 * передаёт вызывающий код — одним запросом на весь список.
	 *
	 * @param array<int, string> $users Карта собеседников для переписок.
	 */
	public function buildDisplayTitle(array $users = []): string
	{
		return \AD90\Recentpages\Provider\TitleBuilder::build(
			(string) $this->type,
			(string) $this->title,
			$this->params ?: [],
			$users
		);
	}
}
