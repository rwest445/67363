<?php

namespace AD90\Recentpages;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUninstallTrait;
	use StepRunnerUpgradeTrait;

	const PERMISSION_GROUP = 'ad90RecentPages';

	public function installStep1()
	{
		$this->schemaManager()->alterTable('xf_user_option', function (Alter $table)
		{
			$table->addColumn('ad90_show_recent_pages', 'tinyint', 3)->setDefault(1);
		});
	}

	public function installStep2()
	{
		$this->schemaManager()->createTable('xf_ad90_recentpages_page', function (Create $table)
		{
			$table->addColumn('user_id', 'int')->unsigned();
			$table->addColumn('url_hash', 'varchar', 32);
			$table->addColumn('url', 'varchar', 255);
			$table->addColumn('type', 'varchar', 40);
			$table->addColumn('params', 'blob');
			$table->addColumn('title', 'varchar', 190);
			$table->addColumn('pinned', 'tinyint', 1)->setDefault(0);
			$table->addColumn('display_order', 'int')->unsigned()->setDefault(0);
			$table->addColumn('last_visit_date', 'int')->unsigned();

			$table->addPrimaryKey(['user_id', 'url_hash']);
			$table->addKey(['user_id', 'pinned', 'display_order'], 'user_pinned_order');
			$table->addKey(['pinned', 'last_visit_date'], 'pinned_visit');
		});
	}

	public function postInstall(array &$stateChanges)
	{
		$this->grantRegisteredPermissions();
	}

	public function postUpgrade($previousVersion, array &$stateChanges)
	{
		// Миграция со старого JSON-хранилища выполняется в шаге 1001130.
		// Права не выдаём — grantRegisteredPermissions() только в postInstall,
		// иначе при снятом флаге «Зарегистрированные» права вернутся.
	}

	/**
	 * 1.1.13: история переезжает из JSON-колонки xf_user_option.ad90_recent_pages
	 * в отдельную таблицу xf_ad90_recentpages_page. Таблица уже создана шагами
	 * установки/обновления схемы ниже; здесь переносим данные, сохраняя
	 * закреплённость и порядок, затем удаляем старую колонку.
	 */
	public function upgrade1001130Step1()
	{
		// Гарантируем таблицу, если обновление пришло со старой версии (до 1.1.13),
		// где её ещё не было.
		$this->ensurePageTable();
	}

	public function upgrade1001130Step2()
	{
		$this->migrateJsonToTable();
	}

	public function upgrade1001130Step3()
	{
		// Колонка-хранилище больше не нужна.
		$this->dropLegacyJsonColumn();
	}

	/** Идемпотентно создаёт таблицу истории (для обновлений со старых версий). */
	protected function ensurePageTable()
	{
		$tables = $this->db()->fetchOne("SHOW TABLES LIKE 'xf_ad90_recentpages_page'");
		if ($tables)
		{
			return;
		}

		$this->schemaManager()->createTable('xf_ad90_recentpages_page', function (Create $table)
		{
			$table->addColumn('user_id', 'int')->unsigned();
			$table->addColumn('url_hash', 'varchar', 32);
			$table->addColumn('url', 'varchar', 255);
			$table->addColumn('type', 'varchar', 40);
			$table->addColumn('params', 'blob');
			$table->addColumn('title', 'varchar', 190);
			$table->addColumn('pinned', 'tinyint', 1)->setDefault(0);
			$table->addColumn('display_order', 'int')->unsigned()->setDefault(0);
			$table->addColumn('last_visit_date', 'int')->unsigned();

			$table->addPrimaryKey(['user_id', 'url_hash']);
			$table->addKey(['user_id', 'pinned', 'display_order'], 'user_pinned_order');
			$table->addKey(['pinned', 'last_visit_date'], 'pinned_visit');
		});
	}

	/**
	 * Переносит записи из JSON в таблицу. Тип для старых записей неизвестен
	 * (JSON хранил только url/title/pinned) — ставим 'legacy', заголовок и
	 * порядок сохраняем. Повторный запуск безопасен (INSERT IGNORE по PK).
	 *
	 * URL проходит ту же canonicalizeUrl, что и при записи визита, чтобы хеш
	 * совпадал с новым записями — дублей не будет.
	 */
	protected function migrateJsonToTable()
	{
		$repo = $this->app->repository('AD90\Recentpages:RecentPage');

		$columns = $this->db()->fetchAllColumn('SHOW COLUMNS FROM xf_user_option');
		if (!in_array('ad90_recent_pages', $columns))
		{
			return;
		}

		$now = \XF::$time;
		$order = 0;

		$rows = $this->db()->fetchAll(
			'SELECT user_id, ad90_recent_pages FROM xf_user_option WHERE ad90_recent_pages IS NOT NULL AND ad90_recent_pages <> \'\''
		);

		foreach ($rows AS $row)
		{
			$userId = (int) $row['user_id'];
			$items = json_decode($row['ad90_recent_pages'], true);
			if (!is_array($items))
			{
				continue;
			}

			$order = 0;
			foreach ($items AS $item)
			{
				$rawUrl = isset($item['url']) ? trim((string) $item['url']) : '';
				$title = isset($item['title']) ? trim((string) $item['title']) : '';
				if ($rawUrl === '' || $title === '')
				{
					continue;
				}

				$url = $repo::canonicalizeUrl($rawUrl);
				if (!$repo::isValidUrl($url))
				{
					continue;
				}

				$hash = $repo::hashUrlFor($url);
				$params = json_encode([], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

				$this->db()->query(
					'INSERT IGNORE INTO xf_ad90_recentpages_page
						(user_id, url_hash, url, type, params, title, pinned, display_order, last_visit_date)
					 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
					[
						$userId,
						$hash,
						substr($url, 0, 255),
						'legacy',
						$params,
						mb_substr($title, 0, 190),
						!empty($item['pinned']) ? 1 : 0,
						++$order,
						$now
					]
				);
			}
		}
	}

	/** Удаляет старую JSON-колонку, если она ещё есть. */
	protected function dropLegacyJsonColumn()
	{
		$columns = $this->db()->fetchAllColumn('SHOW COLUMNS FROM xf_user_option');
		if (in_array('ad90_recent_pages', $columns))
		{
			$this->schemaManager()->alterTable('xf_user_option', function (Alter $table)
			{
				$table->dropColumns(['ad90_recent_pages']);
			});
		}
	}

	public function uninstallStep1()
	{
		$this->schemaManager()->dropTable('xf_ad90_recentpages_page');

		$this->schemaManager()->alterTable('xf_user_option', function (Alter $table)
		{
			$table->dropColumns(['ad90_show_recent_pages']);
		});
	}

	public function uninstallStep2()
	{
		$db = $this->db();
		$db->delete('xf_permission_entry', 'permission_group_id = ?', self::PERMISSION_GROUP);
		$this->app->jobManager()->enqueueUnique('permissionRebuild', 'XF:PermissionRebuild');
	}

	/**
	 * Выдаёт базовые права группе «Зарегистрированные» штатным способом: через
	 * сущность PermissionEntry (не прямым SQL в обход системы прав). Гостям
	 * (группа 1) права не выдаются.
	 */
	protected function grantRegisteredPermissions()
	{
		$em = $this->app->em();

		// Группа «Администраторы» имеет собственную комбинацию прав, в которую
		// «Зарегистрированные» не входят, поэтому права нужно выдать и ей —
		// иначе администратор сразу после установки получает «Нет прав».
		$groupIds = [\XF\Entity\User::GROUP_REG, \XF\Entity\User::GROUP_ADMIN];
		$existingGroups = array_map('intval', $this->db()->fetchAllColumn('SELECT user_group_id FROM xf_user_group'));
		$groupIds = array_values(array_intersect($groupIds, $existingGroups));

		foreach ($groupIds AS $groupId)
		{
			foreach (['view', 'pin'] AS $permissionId)
			{
				// Ищем существующую запись (PK — permission_entry_id, поэтому
				// проверяем напрямую в таблице), чтобы не дублировать при повторном
				// запуске postUpgrade.
				$exists = $this->db()->fetchOne(
					'SELECT permission_entry_id FROM xf_permission_entry
					 WHERE user_group_id = ? AND permission_group_id = ? AND permission_id = ? AND user_id = 0',
					[$groupId, self::PERMISSION_GROUP, $permissionId]
				);

				if ($exists)
				{
					continue;
				}

				$entry = $em->create('XF:PermissionEntry');
				$entry->user_group_id = $groupId;
				$entry->user_id = 0;
				$entry->permission_group_id = self::PERMISSION_GROUP;
				$entry->permission_id = $permissionId;
				$entry->permission_value = 'allow';
				$entry->permission_value_int = 0;
				$entry->save();
			}
		}

		$this->app->jobManager()->enqueueUnique('permissionRebuild', 'XF:PermissionRebuild');
	}
}
