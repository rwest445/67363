<?php

namespace AD90\Recentpages\XF\Entity;

use XF\Mvc\Entity\Structure;

/**
 * Пользовательская настройка ad90_show_recent_pages — включает/выключает блок
 * недавних страниц. Сама история хранится в отдельной таблице
 * xf_ad90_recentpages_page и не является полем UserOption.
 */
class UserOption extends XFCP_UserOption
{
	public static function getStructure(Structure $structure)
	{
		$structure = parent::getStructure($structure);

		$structure->columns['ad90_show_recent_pages'] = [
			'type' => self::BOOL,
			'default' => true
		];

		return $structure;
	}
}
