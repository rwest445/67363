<?php

namespace AD90\Recentpages\Pub\Controller;

use AD90\Recentpages\Limits;
use AD90\Recentpages\Provider\TitleBuilder;
use AD90\Recentpages\Repository\RecentPage as RecentPageRepo;
use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;

/**
 * Публичный API блока недавних страниц.
 *
 * Все операции над историей идут через отдельный контроллер и собственный роут.
 * Запись визита здесь не делается — её выполняет слушатель controller_post_dispatch
 * в том же запросе, что отдаёт страницу (см. Listener\RecordVisit).
 *
 * Ответы списочных операций содержат актуальный набор записей, поэтому клиент
 * не хранит состояние сам и одинаково выглядит на всех устройствах.
 */
class RecentPage extends AbstractController
{
	protected function assertCanUse(): void
	{
		$visitor = \XF::visitor();

		if (!$visitor->user_id || !$visitor->hasPermission('ad90RecentPages', 'view'))
		{
			throw new \XF\Mvc\Reply\Exception(
				$this->error(\XF::phrase('ad90_permission_denied'), 403)
			);
		}
	}

	/**
	 * Базовый URL отдаёт только чтение. Без этого POST на него молча
	 * попадал бы в actionIndex и возвращал список без выполнения операции.
	 */
	protected function assertGetOnly(): void
	{
		if ($this->request->isPost())
		{
			$this->app->response()->header('Allow', 'GET');

			throw $this->exception($this->error(\XF::phrase('requested_page_not_found'), 405));
		}
	}

	/** GET: текущий список (для синхронизации при возврате во вкладку). */
	public function actionIndex()
	{
		$this->assertCanUse();
		$this->assertGetOnly();

		return $this->listReply();
	}

	/** POST: закрепить/открепить. */
	public function actionPin(ParameterBag $params)
	{
		$this->assertCanUse();
		$this->assertPostOnly();

		$visitor = \XF::visitor();
		$userId = (int) $visitor->user_id;

		$pinned = $this->filter('pinned', 'bool');
		if ($pinned && !$visitor->hasPermission('ad90RecentPages', 'pin'))
		{
			return $this->error(\XF::phrase('ad90_permission_denied'), 403);
		}

		$max = Limits::maxItems($visitor);
		$maxPin = Limits::maxPinned($visitor);

		/** @var RecentPageRepo $repo */
		$repo = $this->repository('AD90\Recentpages:RecentPage');

		$result = $repo->setPinned(
			$userId,
			$this->filter('url', 'str'),
			$pinned,
			$maxPin,
			$max
		);

		if ($result === 'pin_limit')
		{
			$reply = $this->listReply();
			$reply->setJsonParams(['error' => 'pin_limit']);

			return $reply;
		}

		return $this->listReply();
	}

	/** POST: убрать страницу из истории. */
	public function actionRemove()
	{
		$this->assertCanUse();
		$this->assertPostOnly();

		$repo = $this->repository('AD90\Recentpages:RecentPage');
		$repo->remove((int) \XF::visitor()->user_id, $this->filter('url', 'str'));

		return $this->listReply();
	}

	/** POST: очистить историю (закреплённые остаются). */
	public function actionClear()
	{
		$this->assertCanUse();
		$this->assertPostOnly();

		$repo = $this->repository('AD90\Recentpages:RecentPage');
		$repo->clear((int) \XF::visitor()->user_id);

		return $this->listReply();
	}

	/** POST: новый порядок после перетаскивания. */
	public function actionOrder()
	{
		$this->assertCanUse();
		$this->assertPostOnly();

		$urls = $this->filter('urls', 'array');

		$repo = $this->repository('AD90\Recentpages:RecentPage');
		$repo->setOrder(
			(int) \XF::visitor()->user_id,
			array_values(array_filter($urls, 'is_string'))
		);

		return $this->listReply();
	}

	/**
	 * POST: скрыть/показать блок (настройка ad90_show_recent_pages).
	 * Сохраняется через сущность UserOption, а не прямым SQL.
	 */
	public function actionHide()
	{
		$this->assertCanUse();
		$this->assertPostOnly();

		if (!$this->request->exists('show'))
		{
			return $this->error(\XF::phrase('ad90_invalid_request'), 400);
		}

		$show = $this->filter('show', 'bool') ? 1 : 0;

		$option = \XF::visitor()->getRelationOrDefault('Option');
		$option->ad90_show_recent_pages = $show;
		$option->save();

		return $this->replyJson(['status' => 'ok']);
	}

	/**
	 * Единый формат ответа со списком. Заголовок отдаётся локализованным
	 * (buildDisplayTitle) — разделитель и подписи типа формирует сервер на языке
	 * просматривающего, в JS уходит готовое поле title. Имена собеседников
	 * подгружаются одним запросом на весь список.
	 */
	protected function listReply()
	{
		$visitor = \XF::visitor();
		$userId = (int) $visitor->user_id;

		/** @var RecentPageRepo $repo */
		$repo = $this->repository('AD90\Recentpages:RecentPage');

		$pages = $repo->findByUser($userId);
		$peerUsers = TitleBuilder::loadPeerUsers($pages);

		$items = [];
		foreach ($pages AS $page)
		{
			$items[] = [
				'url' => $page->url,
				'type' => $page->type,
				'title' => $page->buildDisplayTitle($peerUsers),
				'pinned' => (bool) $page->pinned,
			];
		}

		$reply = $this->message('');
		$reply->setJsonParams([
			'items' => $items,
			'max' => Limits::maxItems($visitor),
			'maxPin' => Limits::maxPinned($visitor),
		]);

		return $reply;
	}

	/** Простой JSON-ответ без списка. */
	protected function replyJson(array $data)
	{
		$reply = $this->message('');
		$reply->setJsonParams($data);

		return $reply;
	}
}
