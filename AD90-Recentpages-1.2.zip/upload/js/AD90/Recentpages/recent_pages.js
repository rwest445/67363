/**
 * AD90 Recentpages — блок недавно посещённых страниц.
 *
 * История живёт на сервере (таблица xf_ad90_recentpages_page), визит пишется
 * слушателем controller_post_dispatch в том же запросе, что отдаёт страницу.
 * Начальный список чипов рендерит сервер (шаблон ad90_recent_pages), поэтому
 * блок виден с первого кадра: этот скрипт только синхронизирует список с
 * сервером (pin/remove/clear/order/hide), перерисовывает его после операций и
 * реализует горизонтальный скролл с ползунком.
 *
 * Контекстное меню чипа перенесено из AD90/Breadcrumb: у XF.Menu нет режима
 * открытия по наведению, поэтому позиционирование и таймеры управляются здесь.
 *
 * Тексты берутся из штатных фраз XF (js-extraPhrases), иконки — из разметки
 * шаблона (xf:fa).
 */
!function (window, document, _undefined)
{
	"use strict";

	XF.Ad90Recentpages = XF.Element.newHandler({
		options: {
			url: '',            // роут контроллера (ad90-recent-pages)
			max: 10,            // максимум незакреплённых
			maxPin: 10,         // максимум закреплённых
			canPin: false,      // право закреплять
			items: '[]',        // начальное состояние (JSON, отдаёт сервер)
			// меню чипа (значения как в AD90/Breadcrumb)
			menuOpenDelay: 180,
			menuSwitchDelay: 120,
			menuCloseDelay: 250,
			menuGap: 8
		},

		root: null,
		scroller: null,
		list: null,
		thumb: null,
		btnClear: null,
		btnHide: null,
		menu: null,

		items: [],
		max: 10,
		maxPin: 10,
		canPin: false,

		hidden: false,
		hideCurrent: false,
		firstRender: true,

		// состояние скролла
		thumbTimer: null,
		drag: null,
		peek: null,
		restTarget: null,
		restTimer: null,

		// состояние меню
		menuUrl: null,
		menuChip: null,
		openTimer: null,
		closeTimer: null,

		// «Отменить» в flash-сообщении: ссылка живёт в разметке сообщения,
		// а обработчик — делегированный, без поиска по DOM.
		undoCb: null,
		undoToken: null,
		undoSeq: 0,
		canHover: !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches),

		// drag&drop
		dragUrl: null,

		// синхронизация
		lastSync: 0,

		init ()
		{
			this.root = this.target;
			this.scroller = this.root.querySelector('.ad90rp-scroller');
			this.list = this.root.querySelector('.ad90rp-list');
			this.thumb = this.root.querySelector('.ad90rp-thumb');
			this.btnClear = this.root.querySelector('.ad90rp-btn--clear');
			this.btnHide = this.root.querySelector('.ad90rp-btn--hide');
			this.menu = document.getElementById('ad90rp-menu');

			this.max = this.readLimit(this.options.max);
			this.maxPin = this.readLimit(this.options.maxPin);
			this.canPin = !!this.options.canPin;

			this.items = this.parseItems(this.options.items);

			// Adopt the server-rendered list without replacing its nodes.
			this.hideCurrent = false;
			this.firstRender = false;
			this.lastSync = Date.now();
			this.build();
			this.bind();
			this.updateEdges();
		},

		readLimit (value)
		{
			var limit = parseInt(value, 10);
			return Number.isFinite(limit) ? Math.max(0, Math.min(100, limit)) : 10;
		},

		destroy ()
		{
			this.closeMenuNow();

			XF.off(document, 'click.ad90rp');
			XF.off(document, 'keydown.ad90rp');
			XF.off(window, 'scroll.ad90rp', this.closeHandler, { capture: true });
			XF.off(window, 'resize.ad90rp');

			clearTimeout(this.thumbTimer);
			clearTimeout(this.openTimer);
			clearTimeout(this.closeTimer);
			clearTimeout(this.pressTimer);
			clearTimeout(this.restTimer);

			if (this.peekWatchFn)
			{
				document.removeEventListener('mousemove', this.peekWatchFn);
			}
		},

		// ------------------------------------------------------------------
		// данные

		parseItems (raw)
		{
			if (typeof raw === 'string')
			{
				try
				{
					raw = JSON.parse(raw);
				}
				catch (e)
				{
					return [];
				}
			}

			if (!Array.isArray(raw))
			{
				return [];
			}

			return raw.filter((it) => it && typeof it.url === 'string' && typeof it.title === 'string')
				.map((it) => ({
					url: it.url,
					type: it.type || '',
					title: it.title,
					pinned: !!it.pinned
				}));
		},

		indexOfUrl (url)
		{
			for (var i = 0; i < this.items.length; i++)
			{
				if (this.items[i].url === url)
				{
					return i;
				}
			}

			return -1;
		},

		pinnedCount ()
		{
			var n = 0;
			for (var i = 0; i < this.items.length; i++)
			{
				if (this.items[i].pinned)
				{
					n++;
				}
			}

			return n;
		},

		// порядок вывода: закреплённые первыми
		sorted ()
		{
			var src = this.items;
			if (this.hideCurrent)
			{
				// Текущую страницу прячем, но закреплённую показываем всегда:
				// закрепление означает «всегда под рукой».
				var cur = this.currentUrl();
				src = src.filter((i) => i.url !== cur || i.pinned);
			}

			return src.filter((i) => i.pinned).concat(src.filter((i) => !i.pinned));
		},

		// URL текущей страницы — для подсветки активного чипа
		currentUrl ()
		{
			if (!this.m_current)
			{
				var path = window.location.pathname;
				this.m_current = path.charAt(path.length - 1) === '/' ? path : path + '/';
			}

			return this.m_current;
		},

		// ------------------------------------------------------------------
		// разметка (разово кэшируем узлы, пересоздаём только чипы в render)

		build ()
		{
			// выносим контекстное меню в body, чтобы оно не обрезалось скроллером
			if (this.menu && this.menu.parentNode !== document.body)
			{
				document.body.appendChild(this.menu);
			}

			this.menuPinRow = this.menu ? this.menu.querySelector('[data-act="pin"]') : null;
			this.menuPinText = this.menuPinRow ? this.menuPinRow.querySelector('.ad90rp-menuText') : null;
			this.menuRemoveRow = this.menu ? this.menu.querySelector('[data-act="remove"]') : null;
			this.menuRemoveText = this.menuRemoveRow ? this.menuRemoveRow.querySelector('.ad90rp-menuText') : null;

			if (this.menuRemoveText)
			{
				this.menuRemoveText.textContent = XF.phrase('ad90_remove');
			}
		},

		// ------------------------------------------------------------------
		// события

		bind ()
		{
			// лента: скролл, колесо, отмена peek
			XF.on(this.list, 'scroll', () => {
				this.updateEdges();
				this.thumb.classList.add('is-scrolling');
				clearTimeout(this.thumbTimer);
				this.thumbTimer = setTimeout(() => this.thumb.classList.remove('is-scrolling'), 700);
			}, { passive: true });

			XF.on(window, 'resize', () => this.updateEdges());
			XF.on(this.list, 'wheel', (e) => this.onWheel(e), { passive: false });
			XF.on(this.list, 'pointerdown', () => this.peekCancel());
			XF.on(this.list, 'touchstart', () => this.peekCancel(), { passive: true });

			// стрелки: peek по наведению, прокрутка по клику
			XF.on(this.scroller, 'mouseover', (e) => this.onArrowOver(e));
			XF.on(this.scroller, 'mouseout', (e) => this.onArrowOut(e));
			XF.on(this.scroller, 'click', (e) => this.onArrowClick(e));

			// ползунок
			XF.on(this.thumb, 'pointerdown', (e) => this.onThumbDown(e));
			XF.on(this.thumb, 'pointermove', (e) => this.onThumbMove(e));
			XF.on(this.thumb, 'pointerup', () => this.endDrag());
			XF.on(this.thumb, 'pointercancel', () => this.endDrag());

			// кнопки
			XF.on(this.btnClear, 'click', () => this.onClear());
			XF.on(this.btnHide, 'click', () => this.onHide());

			// чипы: меню, drag&drop, долгое нажатие
			XF.on(this.list, 'click', (e) => {
				if (this.longPressed)
				{
					e.preventDefault();
					this.longPressed = false;
				}
			});
			XF.on(this.list, 'contextmenu', (e) => {
				var chip = e.target.closest('.ad90rp-item');
				if (!chip)
				{
					return;
				}
				e.preventDefault();
				clearTimeout(this.openTimer);
				this.openMenu(chip);
			});

			if (this.canHover)
			{
				XF.on(this.list, 'mouseover', (e) => {
					var chip = e.target.closest('.ad90rp-item');
					if (!chip)
					{
						return;
					}
					clearTimeout(this.closeTimer);
					if (chip === this.menuChip)
					{
						clearTimeout(this.openTimer);
						return;
					}
					if (this.menuChip)
					{
						this.closeMenuNow();
					}
					clearTimeout(this.openTimer);
					this.openTimer = setTimeout(() => this.openMenu(chip), this.options.menuOpenDelay);
				});

				XF.on(this.list, 'mouseout', (e) => {
					var chip = e.target.closest('.ad90rp-item');
					if (!chip)
					{
						return;
					}
					if (e.relatedTarget && chip.contains(e.relatedTarget))
					{
						return;
					}
					clearTimeout(this.openTimer);
					this.scheduleClose();
				});

				if (this.menu)
				{
					XF.on(this.menu, 'mouseenter', () => clearTimeout(this.closeTimer));
					XF.on(this.menu, 'mouseleave', () => this.scheduleClose());
				}
			}

			// долгое нажатие на тач: меню по наведению там недоступно, поэтому
			// открываем тем же жестом, что и раньше
			XF.on(this.list, 'touchstart', (e) => {
				var chip = e.target.closest('.ad90rp-item');
				if (!chip)
				{
					return;
				}
				this.longPressed = false;
				this.cancelPress();
				this.pressTimer = setTimeout(() => {
					this.longPressed = true;
					this.openMenu(chip);
				}, 500);
			}, { passive: true });
			XF.on(this.list, 'touchend', () => this.cancelPress());
			XF.on(this.list, 'touchmove', () => this.cancelPress(), { passive: true });
			XF.on(this.list, 'touchcancel', () => this.cancelPress());

			// drag&drop
			XF.on(this.list, 'dragstart', (e) => this.onDragStart(e));
			XF.on(this.list, 'dragover', (e) => this.onDragOver(e));
			XF.on(this.list, 'drop', (e) => this.onDrop(e));
			XF.on(this.list, 'dragend', () => {
				this.dragUrl = null;
				this.clearOver();
			});

			// действия меню
			if (this.menu)
			{
				XF.on(this.menu, 'click', (e) => this.onMenuAction(e));
			}

			// «Отменить» в flash-сообщении: делегированный клик от самого события,
			// без поиска сообщения по DOM.
			XF.on(document.body, 'click', (e) => this.onUndoClick(e));

			// Глобальное закрытие меню: клик вне, Escape, прокрутка и ресайз.
			// Обработчики с namespace снимаются в destroy().
			this.closeHandler = this.closeMenuNow.bind(this);
			XF.on(document, 'click.ad90rp', (e) => this.onDocumentClick(e));
			XF.on(document, 'keydown.ad90rp', (e) => this.onKeyDown(e));
			XF.on(window, 'scroll.ad90rp', this.closeHandler, { capture: true });
			XF.on(window, 'resize.ad90rp', this.closeHandler);

			// размеры могут измениться после загрузки шрифтов/стилей
			if (window.ResizeObserver)
			{
				try
				{
					this.resizeObserver = new ResizeObserver(() => this.updateEdges());
					this.resizeObserver.observe(this.list);
				}
				catch (e)
				{
				}
			}
			if (document.fonts && document.fonts.ready)
			{
				document.fonts.ready.then(() => this.updateEdges());
			}

			// синхронизация между вкладками/устройствами при возврате
			XF.on(document, 'visibilitychange', () => {
				if (!document.hidden)
				{
					this.refresh(false);
				}
			});
			XF.on(window, 'focus', () => this.refresh(false));
		},

		cancelPress ()
		{
			if (this.pressTimer)
			{
				clearTimeout(this.pressTimer);
				this.pressTimer = null;
			}
		},

		// ------------------------------------------------------------------
		// рендер

		render ()
		{
			var items = this.sorted();
			this.root.hidden = this.hidden || !items.length;
			var nodes = this.list.querySelectorAll('.ad90rp-item');
			var unchanged = nodes.length === items.length && items.every((item, index) => {
				var node = nodes[index];
				return node.getAttribute('data-url') === item.url
					&& node.classList.contains('is-pinned') === item.pinned
					&& node.querySelector('.ad90rp-itemTitle').textContent === item.title;
			});
			if (unchanged)
			{
				this.updateEdges();
				return;
			}
			this.closeMenuNow();
			var before = (this.firstRender || this.root.hidden) ? null : this.snapshot();
			var sl = this.list.scrollLeft;
			var cur = this.currentUrl();

			this.list.innerHTML = '';
			var active = null;

			items.forEach(function (it, n) {
				var a = document.createElement('a');
				a.className = 'ad90rp-item' + (it.pinned ? ' is-pinned' : '') + (it.url === cur ? ' is-active' : '');
				a.href = it.url;
				a.draggable = true;
				a.setAttribute('data-url', it.url);

				if (it.pinned)
				{
					var pi = document.createElement('span');
					pi.className = 'ad90rp-pinIcon';
					pi.innerHTML = this.pinSvg();
					a.appendChild(pi);
				}

				var s = document.createElement('span');
				s.className = 'ad90rp-itemTitle';
				s.textContent = it.title;
				a.appendChild(s);

				this.list.appendChild(a);
				if (it.url === cur)
				{
					active = a;
				}
			}, this);


			var empty = !items.length;
			this.root.hidden = this.hidden || empty;

			if (this.firstRender && active && !this.root.hidden)
			{
				this.list.scrollLeft = Math.max(0, active.offsetLeft - this.list.clientWidth / 2 + active.offsetWidth / 2);
			}
			else
			{
				this.list.scrollLeft = sl;
			}

			if (before)
			{
				this.flip(before);
			}

			this.firstRender = false;
			this.updateEdges();
		},

		// Иконка-канцелярская кнопка для закреплённого чипа (та же, что в шаблоне и LESS).
		pinSvg ()
		{
			return '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" ' +
				'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" ' +
				'stroke-linejoin="round" aria-hidden="true"><path d="M12 17v5"/>' +
				'<path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/></svg>';
		},

		snapshot ()
		{
			var map = {};
			var chips = this.list.querySelectorAll('.ad90rp-item');
			for (var i = 0; i < chips.length; i++)
			{
				map[chips[i].getAttribute('data-url')] = chips[i].getBoundingClientRect().left;
			}

			return map;
		},

		// FLIP-анимация: чипы плавно доезжают до новых позиций
		flip (before)
		{
			var moved = [];
			var chips = this.list.querySelectorAll('.ad90rp-item');
			for (var i = 0; i < chips.length; i++)
			{
				var old = before[chips[i].getAttribute('data-url')];
				if (old === undefined)
				{
					continue;
				}
				var dx = old - chips[i].getBoundingClientRect().left;
				if (Math.abs(dx) > 1)
				{
					chips[i].style.transition = 'none';
					chips[i].style.transform = 'translateX(' + dx + 'px)';
					moved.push(chips[i]);
				}
			}

			if (!moved.length)
			{
				return;
			}

			this.list.getBoundingClientRect();
			moved.forEach(function (c) {
				c.style.transition = 'transform .3s cubic-bezier(.2, .7, .2, 1)';
				c.style.transform = '';
			});
			setTimeout(function () {
				moved.forEach(function (c) { c.style.transition = ''; });
			}, 340);
		},

		// ------------------------------------------------------------------
		// сервер: единая точка синхронизации

		// Каждая операция — отдельный экшен контроллера (baseUrl + /action),
		// потому что XF маршрутизирует по пути, а не по полю action в теле.
		// actionIndex (базовый URL) отвечает только на GET.
		actionUrl (action)
		{
			var base = this.options.url || '';
			if (!base)
			{
				return '';
			}

			return base.replace(/\/+$/, '') + '/' + action;
		},

		// Ответ содержит актуальный список — применяем его целиком.
		sync (payload, cb)
		{
			var action = payload && payload.action ? payload.action : '';
			var url = this.actionUrl(action);

			if (!url || !window.XF || typeof XF.ajax !== 'function')
			{
				if (cb)
				{
					cb(false, null);
				}
				return;
			}

			var data = {};
			for (var key in payload)
			{
				if (key !== 'action')
				{
					data[key] = payload[key];
				}
			}

			try
			{
				XF.ajax('post', url, data, (res) => {
					if (res && res.items)
					{
						this.items = this.parseItems(res.items);
						if (typeof res.max === 'number')
						{
							this.max = res.max;
						}
						if (typeof res.maxPin === 'number')
						{
							this.maxPin = res.maxPin;
						}
					}
					if (cb)
					{
						cb(true, res || {});
					}
				}, { skipDefault: true, skipError: true, global: false }).catch(function () {
					if (cb)
					{
						cb(false, null);
					}
				});
			}
			catch (e)
			{
				if (cb)
				{
					cb(false, null);
				}
			}
		},

		// Актуальный список при возврате во вкладку (могло измениться на другом устройстве).
		refresh (force)
		{
			if (!force && Date.now() - this.lastSync < 60000)
			{
				return;
			}
			if (!this.options.url || !window.XF || typeof XF.ajax !== 'function')
			{
				return;
			}
			this.lastSync = Date.now();

			var self = this;
			try
			{
				XF.ajax('get', this.options.url, {}, function (res) {
					if (res && res.items)
					{
						self.items = self.parseItems(res.items);
						if (typeof res.max === 'number') { self.max = self.readLimit(res.max); }
						if (typeof res.maxPin === 'number') { self.maxPin = self.readLimit(res.maxPin); }
						self.hideCurrent = false;
						self.render();
					}
				}, { skipDefault: true, skipError: true, global: false }).catch(function () {});
			}
			catch (e) {}
		},

		trim ()
		{
			var n = 0;
			for (var i = 0; i < this.items.length; i++)
			{
				if (!this.items[i].pinned)
				{
					n++;
					if (n > this.max)
					{
						this.items.splice(i, 1);
						i--;
					}
				}
			}
		},

		// ------------------------------------------------------------------
		// действия кнопок и меню

		onClear ()
		{
			this.quickAction();
			var self = this;
			this.animateOut(function (u) {
				var i = self.indexOfUrl(u);
				return i > -1 && !self.items[i].pinned;
			}, function () {
				self.items = self.items.filter(function (i) { return i.pinned; });
				self.render();
				self.flash(XF.phrase('ad90_msg_cleared'));
				self.sync({ action: 'clear' }, function (ok) { if (ok) { self.render(); } });
			});
		},

		onHide ()
		{
			var self = this;
			var end = this.globalAction(500);
			this.hidden = true;
			this.render();
			this.flashHidden();
			this.sync({ action: 'hide', show: 0 }, function (ok, res) {
				end();
				if (!(ok && res && res.status === 'ok'))
				{
					self.undoToken = null;
					self.hidden = false;
					self.render();
				}
			});
		},

		onMenuAction (e)
		{
			var row = e.target.closest('[data-act]');
			if (!row)
			{
				return;
			}
			e.preventDefault();

			var url = this.menuUrl;
			if (url === null)
			{
				return;
			}
			var act = row.getAttribute('data-act');
			this.closeMenuNow();

			var idx = this.indexOfUrl(url);
			if (idx < 0)
			{
				return;
			}

			var self = this;

			if (act === 'pin')
			{
				if (!this.canPin)
				{
					return;
				}

				var item = this.items[idx];
				if (!item.pinned && this.pinnedCount() >= this.maxPin)
				{
					XF.alert(XF.phrase('ad90_pin_limit', { count: this.maxPin }));
					return;
				}

				this.quickAction();
				var wasPinned = item.pinned;
				item.pinned = !wasPinned;
				this.trim();
				this.render();
				this.sync({ action: 'pin', url: url, pinned: item.pinned ? 1 : 0 }, function (ok, res) {
					if (!ok)
					{
						var back = self.indexOfUrl(url);
						if (back > -1)
						{
							self.items[back].pinned = wasPinned;
							self.render();
						}
						return;
					}
					if (res && res.error === 'pin_limit')
					{
						XF.alert(XF.phrase('ad90_pin_limit', { count: self.maxPin }));
						self.render();
						return;
					}
					self.render();
				});
			}
			else
			{
				this.quickAction();
				this.animateOut(function (u) { return u === url; }, function () {
					var j = self.indexOfUrl(url);
					if (j > -1)
					{
						self.items.splice(j, 1);
					}
					self.render();
					self.sync({ action: 'remove', url: url }, function (ok) { if (ok) { self.render(); } });
				});
			}
		},

		// ------------------------------------------------------------------
		// контекстное меню чипа — перенесено из AD90/Breadcrumb,
		// у XF.Menu нет режима открытия по наведению

		menuIsOpen ()
		{
			return !!(this.menu && this.menu.classList.contains('is-active'));
		},

		placeMenu (chip)
		{
			var url = chip.getAttribute('data-url');
			var idx = this.indexOfUrl(url);
			if (idx < 0 || !this.menu)
			{
				return;
			}

			this.closeMenuNow();

			this.menuChip = chip;
			this.menuUrl = url;

			if (this.menuPinRow)
			{
				this.menuPinRow.style.display = this.canPin ? '' : 'none';
			}
			if (this.menuPinText)
			{
				this.menuPinText.textContent = this.items[idx].pinned ? XF.phrase('ad90_unpin') : XF.phrase('ad90_pin');
			}

			// position: fixed — меню не зависит от скроллера и не обрезается им
			var r = chip.getBoundingClientRect();
			var width = this.menu.offsetWidth;
			var gap = parseInt(this.options.menuGap, 10) || 0;
			// выравнивание по левому краю чипа; сдвиг только если меню не влезает в окно
			var left = Math.min(r.left, window.innerWidth - width - 8);
			this.menu.style.left = Math.max(8, left) + 'px';
			this.menu.style.top = (r.bottom + gap) + 'px';

			// принудительный пересчёт стилей: без него анимация из начального
			// состояния не запускается
			this.menu.getBoundingClientRect();
			this.menu.classList.add('is-active');
			this.menu.setAttribute('aria-hidden', 'false');
			chip.setAttribute('aria-expanded', 'true');
		},

		openMenu (chip)
		{
			clearTimeout(this.openTimer);

			if (this.dragUrl !== null)
			{
				// во время перетаскивания меню не открывается
				return;
			}

			if (this.menuChip === chip)
			{
				clearTimeout(this.closeTimer);
				return;
			}

			if (this.menuChip)
			{
				// гасим предыдущее и открываем новое без мигания
				this.closeMenuNow();
				var self = this;
				this.openTimer = setTimeout(function () { self.placeMenu(chip); }, this.options.menuSwitchDelay);
				return;
			}

			this.placeMenu(chip);
		},

		closeMenuNow ()
		{
			clearTimeout(this.openTimer);

			if (!this.menu)
			{
				this.menuChip = null;
				this.menuUrl = null;
				return;
			}

			this.menu.classList.remove('is-active');
			this.menu.setAttribute('aria-hidden', 'true');

			if (this.menuChip)
			{
				this.menuChip.removeAttribute('aria-expanded');
			}

			this.menuChip = null;
			this.menuUrl = null;
		},

		scheduleClose ()
		{
			clearTimeout(this.closeTimer);
			this.closeTimer = setTimeout(() => this.closeMenuNow(), this.options.menuCloseDelay);
		},

		onDocumentClick (e)
		{
			if (!this.menuChip)
			{
				return;
			}
			if (this.menuChip.contains(e.target) || (this.menu && this.menu.contains(e.target)))
			{
				return;
			}

			this.closeMenuNow();
		},

		onKeyDown (e)
		{
			if (e.key === 'Escape')
			{
				this.closeMenuNow();
			}
		},

		// ------------------------------------------------------------------
		// скроллер

		thumbMetrics ()
		{
			var sw = this.list.scrollWidth;
			var cw = this.list.clientWidth;
			var w = Math.max(32, cw * cw / sw);
			return { sw: sw, cw: cw, w: w, track: cw - w, max: sw - cw };
		},

		updateThumb ()
		{
			var m = this.thumbMetrics();
			if (m.max <= 1)
			{
				this.thumb.style.display = 'none';
				return;
			}
			this.thumb.style.display = 'block';
			this.thumb.style.width = m.w + 'px';
			this.thumb.style.transform = 'translateX(' + (this.list.scrollLeft / m.max * m.track) + 'px)';
		},

		updateEdges ()
		{
			var max = this.list.scrollWidth - this.list.clientWidth;
			var sl = this.list.scrollLeft;
			this.scroller.classList.toggle('has-start', max > 1 && sl > 1);
			this.scroller.classList.toggle('has-end', max > 1 && sl < max - 1);
			this.updateThumb();
		},

		onWheel (e)
		{
			if (this.list.scrollWidth <= this.list.clientWidth)
			{
				return;
			}
			if (Math.abs(e.deltaY) > Math.abs(e.deltaX))
			{
				this.list.scrollLeft += e.deltaY;
				e.preventDefault();
			}
		},

		peekCancel ()
		{
			this.peek = null;
			this.restTarget = null;
			clearTimeout(this.restTimer);
		},

		peekStart (act)
		{
			if (this.peek)
			{
				return;
			}
			clearTimeout(this.restTimer);
			var dir = act.classList.contains('ad90rp-arrow--start') ? -1 : 1;
			var origin = this.restTarget !== null ? this.restTarget : this.list.scrollLeft;
			var max = this.list.scrollWidth - this.list.clientWidth;
			var target = Math.max(0, Math.min(max, origin + dir * 56));
			if (Math.abs(target - origin) < 2)
			{
				return;
			}
			this.peek = { origin: origin, target: target };
			try { this.list.scrollTo({ left: target, behavior: 'smooth' }); } catch (e) { this.list.scrollLeft = target; }
			var self = this;
			this.peekWatchFn = function (e) {
				if (!self.peek) { document.removeEventListener('mousemove', self.peekWatchFn); return; }
				var t = e.target;
				if (!(t && t.closest && t.closest('.ad90rp-arrow'))) { self.peekEnd(); }
			};
			document.addEventListener('mousemove', this.peekWatchFn);
		},

		peekEnd ()
		{
			if (this.peekWatchFn)
			{
				document.removeEventListener('mousemove', this.peekWatchFn);
			}
			if (!this.peek)
			{
				return;
			}
			var origin = this.peek.origin;
			this.peek = null;
			this.restTarget = origin;
			try { this.list.scrollTo({ left: origin, behavior: 'smooth' }); } catch (e) { this.list.scrollLeft = origin; }
			clearTimeout(this.restTimer);
			var self = this;
			this.restTimer = setTimeout(function () { self.restTarget = null; }, 450);
		},

		onArrowOver (e)
		{
			var act = e.target.closest ? e.target.closest('.ad90rp-arrow') : null;
			if (!act || (e.relatedTarget && act.contains(e.relatedTarget)))
			{
				return;
			}
			this.peekStart(act);
		},

		onArrowOut (e)
		{
			var act = e.target.closest ? e.target.closest('.ad90rp-arrow') : null;
			if (!act || (e.relatedTarget && act.contains(e.relatedTarget)))
			{
				return;
			}
			this.peekEnd();
		},

		onArrowClick (e)
		{
			var act = e.target.closest ? e.target.closest('.ad90rp-arrow') : null;
			if (!act)
			{
				return;
			}
			var base = this.peek ? this.peek.target : this.list.scrollLeft;
			this.peekCancel();
			var dir = act.classList.contains('ad90rp-arrow--start') ? -1 : 1;
			var max = this.list.scrollWidth - this.list.clientWidth;
			var target = Math.max(0, Math.min(max, base + dir * Math.max(80, this.list.clientWidth * 0.75)));
			try { this.list.scrollTo({ left: target, behavior: 'smooth' }); } catch (err) { this.list.scrollLeft = target; }
		},

		onThumbDown (e)
		{
			e.preventDefault();
			this.peekCancel();
			this.drag = { x: e.clientX, left: this.list.scrollLeft };
			this.thumb.classList.add('is-drag');
			try { this.thumb.setPointerCapture(e.pointerId); } catch (err) {}
		},

		onThumbMove (e)
		{
			if (!this.drag)
			{
				return;
			}
			var m = this.thumbMetrics();
			if (m.track <= 0)
			{
				return;
			}
			this.list.scrollLeft = this.drag.left + (e.clientX - this.drag.x) * m.max / m.track;
		},

		endDrag ()
		{
			this.drag = null;
			this.thumb.classList.remove('is-drag');
		},

		// ------------------------------------------------------------------
		// drag & drop сортировка

		onDragStart (e)
		{
			var chip = e.target.closest('.ad90rp-item');
			if (!chip)
			{
				return;
			}
			this.dragUrl = chip.getAttribute('data-url');
			chip.classList.add('is-dragging');
			this.closeMenuNow();
			try
			{
				e.dataTransfer.effectAllowed = 'move';
				e.dataTransfer.setData('text/plain', this.dragUrl);
			}
			catch (err) {}
		},

		onDragOver (e)
		{
			if (this.dragUrl === null)
			{
				return;
			}
			e.preventDefault();
			var chip = e.target.closest('.ad90rp-item');
			var over = this.list.querySelectorAll('.is-dragOver');
			for (var i = 0; i < over.length; i++)
			{
				over[i].classList.remove('is-dragOver');
			}
			if (chip && chip.getAttribute('data-url') !== this.dragUrl)
			{
				chip.classList.add('is-dragOver');
			}
		},

		onDrop (e)
		{
			if (this.dragUrl === null)
			{
				return;
			}
			e.preventDefault();
			var chip = e.target.closest('.ad90rp-item');
			if (chip)
			{
				var targetUrl = chip.getAttribute('data-url');
				var disp = this.sorted();
				var from = -1, to = -1;
				for (var i = 0; i < disp.length; i++)
				{
					if (disp[i].url === this.dragUrl) { from = i; }
					if (disp[i].url === targetUrl) { to = i; }
				}
				if (from > -1 && to > -1 && from !== to)
				{
					var moved = disp.splice(from, 1)[0];
					var insertAt = disp.indexOf(disp.filter(function (x) { return x.url === targetUrl; })[0]);
					disp.splice(from < to ? insertAt + 1 : insertAt, 0, moved);
					this.items = disp;
					this.quickAction();
					var self = this;
					this.sync({ action: 'order', urls: disp.map(function (x) { return x.url; }) }, function (ok) {
						if (ok) { self.render(); }
					});
				}
			}
			this.dragUrl = null;
			this.render();
		},

		clearOver ()
		{
			var els = this.list.querySelectorAll('.is-dragOver, .is-dragging');
			for (var i = 0; i < els.length; i++)
			{
				els[i].classList.remove('is-dragOver');
				els[i].classList.remove('is-dragging');
			}
		},

		// ------------------------------------------------------------------
		// индикатор действия (XF.ActionIndicator) + flash-сообщения

		indicatorShow ()
		{
			this.m_indicatorUsed = (this.m_indicatorUsed || 0) + 1;
			if (this.m_indicatorUsed > 1)
			{
				return;
			}
			if (window.XF && XF.ActionIndicator && typeof XF.ActionIndicator.show === 'function')
			{
				XF.ActionIndicator.show();
			}
		},

		indicatorHide ()
		{
			if (!this.m_indicatorUsed)
			{
				return;
			}
			this.m_indicatorUsed--;
			if (this.m_indicatorUsed > 0)
			{
				return;
			}
			if (window.XF && XF.ActionIndicator && typeof XF.ActionIndicator.hide === 'function')
			{
				XF.ActionIndicator.hide();
			}
		},

		globalAction (minMs)
		{
			var t0 = Date.now();
			var done = false;
			var self = this;
			this.indicatorShow();
			return function () {
				if (done) { return; }
				done = true;
				setTimeout(function () { self.indicatorHide(); }, Math.max(0, (minMs || 400) - (Date.now() - t0)));
			};
		},

		quickAction ()
		{
			this.globalAction(400)();
		},

		flash (text, ms)
		{
			if (text && window.XF && typeof XF.flashMessage === 'function')
			{
				XF.flashMessage(text, ms || 2500);
			}
		},

		dismissFlash (fm)
		{
			if (!fm)
			{
				return;
			}
			fm.classList.remove('is-active');
			setTimeout(function () { if (fm.parentNode) { fm.parentNode.removeChild(fm); } }, 250);
		},

		// «История скрыта… Отменить». Ссылка приходит в разметке сообщения
		// (XF.flashMessage принимает HTML), а клик ловится делегированно —
		// поиска сообщения по DOM нет, элемент берётся от самого события.
		flashHidden ()
		{
			if (!(window.XF && typeof XF.flashMessage === 'function'))
			{
				return null;
			}

			var token = 'ad90rp-undo-' + (++this.undoSeq);
			this.undoToken = token;

			var html = XF.htmlspecialchars(XF.phrase('ad90_msg_hidden')) +
				' <a href="#" class="ad90rp-undo" data-undo="' + token + '">' +
				XF.htmlspecialchars(XF.phrase('ad90_undo')) + '</a>';

			XF.flashMessage(html, 8000, () => {
				if (this.undoToken === token)
				{
					this.undoToken = null;
				}
			});

			return token;
		},

		onUndoClick (e)
		{
			var link = e.target.closest ? e.target.closest('.ad90rp-undo') : null;
			if (!link || !this.undoToken || link.getAttribute('data-undo') !== this.undoToken)
			{
				return;
			}

			e.preventDefault();
			e.stopPropagation();

			this.undoToken = null;
			this.dismissFlash(link.closest('.flashMessage'));

			var end = this.globalAction(500);
			var self = this;
			this.hidden = false;
			this.render();

			this.sync({ action: 'hide', show: 1 }, function (ok, res) {
				end();
				if (!(ok && res && res.status === 'ok'))
				{
					self.hidden = true;
					self.render();
				}
			});
		},

		// ------------------------------------------------------------------
		// плавное удаление чипов перед действием

		animateOut (pred, done)
		{
			var chips = this.list.querySelectorAll('.ad90rp-item');
			var any = false;
			for (var i = 0; i < chips.length; i++)
			{
				if (pred(chips[i].getAttribute('data-url')))
				{
					chips[i].classList.add('is-removing');
					any = true;
				}
			}
			if (!any)
			{
				done();
				return;
			}
			setTimeout(done, 210);
		}
	});

	XF.Element.register('recent-pages', 'XF.Ad90Recentpages');
}
(window, document);
