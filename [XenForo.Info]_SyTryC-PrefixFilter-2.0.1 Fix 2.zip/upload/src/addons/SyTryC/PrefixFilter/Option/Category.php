<?php

namespace SyTryC\PrefixFilter\Option;

use XF\Entity\Option;

class Category extends \XF\Option\AbstractOption
{
	public static function renderSelectMultiple(Option $option, array $htmlParams)
    {
        $addOns = \XF::app()->container('addon.cache');

        if(array_key_exists('XFRM', $addOns))
        {
            /** @var \XFRM\Repository\Category $CategoryRepo */
            $CategoryRepo = \XF::repository('XFRM:Category');
            $data['choices'] = $CategoryRepo->getCategoryOptionsData();
            $data['choices'][0]['label'] = \XF::phrase('(none)');
            $data['controlOptions'] = self::getControlOptions($option, $htmlParams);
            $data['controlOptions']['multiple'] = true;
            $data['controlOptions']['size'] = 8;
            $data['rowOptions'] = self::getRowOptions($option, $htmlParams);
            
            return self::getTemplater()->formSelectRow(
                $data['controlOptions'], $data['choices'], $data['rowOptions']
            );
        }
        else
        {
            return self::getTemplater()->renderTemplate('admin:sc_pf_xfrm');
        }
    }
}