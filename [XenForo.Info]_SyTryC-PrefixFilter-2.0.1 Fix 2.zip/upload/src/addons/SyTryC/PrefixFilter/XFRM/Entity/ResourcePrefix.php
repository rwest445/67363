<?php

namespace SyTryC\PrefixFilter\XFRM\Entity;

use XF\Mvc\Entity\Entity;

class ResourcePrefix extends XFCP_ResourcePrefix
{
    public function getTotalPrefixes(Entity $entity)
    {
        $visitor = \XF::visitor();
        $resourceState = ['visible'];

        if ($visitor->hasResourceCategoryPermission($entity->getEntityId(), 'viewModerated'))
        {
            $resourceState[] = 'moderated';
        }

        if ($visitor->hasResourceCategoryPermission($entity->getEntityId(), 'viewDeleted'))
        {
            $resourceState[] = 'deleted';
        }

        return $this->finder('XFRM:ResourceItem')
                    ->where([
                        'resource_category_id' => $entity->getEntityId(), 
                        'prefix_id' => $this->prefix_id,
                        'resource_state' => $resourceState
                    ])
                    ->total();
    }
}