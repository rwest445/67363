<?php

namespace SyTryC\PrefixFilter\XF\Entity;

use XF\Mvc\Entity\Entity;

class ThreadPrefix extends XFCP_ThreadPrefix
{
    public function getTotalPrefixes(Entity $entity)
    {
        $visitor = \XF::visitor();

        $discussionState = ['visible'];
        if ($visitor->hasNodePermission($entity->getEntityId(), 'viewModerated'))
        {
            $discussionState[] = 'moderated';
        }
        if ($visitor->hasNodePermission($entity->getEntityId(), 'viewDeleted'))
        {
            $discussionState[] = 'deleted';
        }

        return $this->finder('XF:Thread')
                    ->where([
                        'node_id' => $entity->getEntityId(), 
                        'prefix_id' => $this->prefix_id,
                        'discussion_state' => $discussionState,
                    ])
                    ->total();
    }
}