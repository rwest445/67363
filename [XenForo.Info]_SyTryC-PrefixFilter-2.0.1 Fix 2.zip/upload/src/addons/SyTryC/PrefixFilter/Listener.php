<?php

namespace SyTryC\PrefixFilter;

use SyTryC\PrefixFilter\Template\TemplaterSetup;

class Listener
{
    /**
     * @param \XF\Container $container
     * @param \XF\Template\Templater $templater
     * @throws \Exception
     */
    public static function templaterSetup(\XF\Container $container, \XF\Template\Templater &$templater)
    {
        /** @var TemplaterSetup $templaterSetup */
        $class = \XF::extendClass('SyTryC\PrefixFilter\Template\TemplaterSetup');
        $templaterSetup = new $class();

        $templater->addFunction('prefix_filter', [$templaterSetup, 'fnPrefixFilter']);
    }
}