<?php

namespace SyTryC\PrefixFilter\Template;

class TemplaterSetup
{
    public function fnPrefixFilter($templater, &$escape, $contentType, $prefixId, $link, $totalPrefix)
    {
        $prefix = $templater->fnPrefix($templater, $escape, $contentType, $prefixId);

        $titlePrefix = $templater->func('prefix_title', [$contentType, $prefixId], false);

        $title = $titlePrefix;

        if(!\XF::options()->sc_pf_show_prefixes_number) {
            $title .= ' (' . $totalPrefix . ')';
        }

        $prefix = str_replace($titlePrefix, $title, $prefix);

        return "<a href=\"$link\" class=\"labelLink\">$prefix</a>";
    }
}